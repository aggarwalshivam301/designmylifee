const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false }));

// Routes
app.use('/api/auth',    require('./routes/authRoutes'));
app.use('/api/habits',  require('./routes/habitRoutes'));
app.use('/api/goals',   require('./routes/goalRoutes'));
app.use('/api/tasks',   require('./routes/taskRoutes'));
app.use('/api/journal', require('./routes/journalRoutes'));
app.use('/api/ai',      require('./routes/aiRoutes'));

app.get('/health', (req, res) =>
  res.json({ status: 'ok', ai: !!process.env.AI_API_KEY, timestamp: new Date() })
);

app.use((req, res) => res.status(404).json({ message: 'Route not found' }));

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

module.exports = app;
