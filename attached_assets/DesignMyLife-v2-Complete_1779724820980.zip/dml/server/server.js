require('dotenv').config();
const app = require('./app');
const connectDB = require('./config/db');

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`
╔══════════════════════════════════════════╗
║        DesignMyLife Server v2.0          ║
║  Port     : ${PORT}                          ║
║  Env      : ${process.env.NODE_ENV || 'development'}                ║
║  AI       : ${process.env.AI_API_KEY ? '✅ Configured' : '⚠️  No API key (BCI works)'}  ║
╚══════════════════════════════════════════╝
    `);
  });
});
