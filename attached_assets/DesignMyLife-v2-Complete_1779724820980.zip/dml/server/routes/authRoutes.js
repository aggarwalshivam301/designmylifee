// authRoutes.js
const r = require('express').Router();
const c = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');
r.post('/register', c.register);
r.post('/login',    c.login);
r.get('/profile',          protect, c.getProfile);
r.put('/profile',          protect, c.updateProfile);
r.put('/change-password',  protect, c.changePassword);
r.put('/toggle-ai',        protect, c.toggleAI);
module.exports = r;
