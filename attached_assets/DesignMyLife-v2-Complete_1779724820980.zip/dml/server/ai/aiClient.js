const axios = require('axios');

class AIClient {
  constructor() {
    this.provider  = process.env.AI_PROVIDER  || 'anthropic';
    this.apiKey    = process.env.AI_API_KEY   || '';
    this.model     = process.env.AI_MODEL     || 'claude-3-5-sonnet-20241022';
    this.timeout   = parseInt(process.env.AI_TIMEOUT)    || 30000;
    this.retries   = parseInt(process.env.AI_MAX_RETRIES) || 2;
  }

  isConfigured() { return !!this.apiKey; }

  async generate(prompt, opts = {}) {
    if (!this.isConfigured()) throw new Error('AI_API_KEY not set');
    const { temperature = 0.4, maxTokens = 1200 } = opts;

    for (let attempt = 1; attempt <= this.retries; attempt++) {
      try {
        return this.provider === 'openai'
          ? await this._openai(prompt, { temperature, maxTokens })
          : await this._anthropic(prompt, { temperature, maxTokens });
      } catch (err) {
        if (attempt === this.retries) throw err;
        await new Promise(r => setTimeout(r, 1000 * attempt));
      }
    }
  }

  async _anthropic(prompt, { temperature, maxTokens }) {
    const res = await axios.post('https://api.anthropic.com/v1/messages', {
      model: this.model, max_tokens: maxTokens, temperature,
      system: 'You are an expert behavioral coach. Return ONLY valid JSON — no markdown, no explanation.',
      messages: [{ role: 'user', content: prompt }]
    }, {
      headers: { 'Content-Type': 'application/json', 'x-api-key': this.apiKey, 'anthropic-version': '2023-06-01' },
      timeout: this.timeout
    });
    return this._extractJSON(res.data.content[0].text);
  }

  async _openai(prompt, { temperature, maxTokens }) {
    const res = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: this.model || 'gpt-4',
      messages: [
        { role: 'system', content: 'You are an expert behavioral coach. Return ONLY valid JSON.' },
        { role: 'user', content: prompt }
      ],
      temperature, max_tokens: maxTokens
    }, {
      headers: { 'Authorization': `Bearer ${this.apiKey}` },
      timeout: this.timeout
    });
    return this._extractJSON(res.data.choices[0].message.content);
  }

  _extractJSON(text) {
    try { return JSON.parse(text); } catch (_) {}
    const m = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || text.match(/(\{[\s\S]*\})/);
    if (m) { try { return JSON.parse(m[1]); } catch (_) {} }
    throw new Error('No valid JSON in AI response');
  }

  async isAvailable() {
    if (!this.isConfigured()) return false;
    try {
      await this.generate('Reply {"ok":true}', { maxTokens: 10 });
      return true;
    } catch { return false; }
  }
}

module.exports = new AIClient();
