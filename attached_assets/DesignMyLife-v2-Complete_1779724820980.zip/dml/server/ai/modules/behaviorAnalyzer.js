const aiClient = require('../aiClient');
const bci      = require('../../services/bciCalculator');

const analyze = async (habits, opts = {}) => {
  const bciResult = bci.calculateBCI(habits, opts.goal || null);

  if (!opts.useAI || !aiClient.isConfigured()) {
    return { ...bciResult, mode: 'bci_only', aiInsights: null };
  }

  try {
    const prompt = `Analyze these habit behaviors and BCI data. Return JSON only.

HABITS: ${JSON.stringify(habits.map(h => ({ name: h.name, streak: h.currentStreak, freq: h.frequency })))}
BCI Score: ${bciResult.score}/100
Breakdown: S=${bciResult.breakdown.streakConsistency} C=${bciResult.breakdown.completionRate} T=${bciResult.breakdown.timeConsistency}

Return this exact JSON structure:
{
  "patterns": ["string","string","string"],
  "psychologicalFactors": ["string","string"],
  "actionableTips": ["string","string","string"],
  "weeklyFocus": "string"
}`;

    const insights = await aiClient.generate(prompt);
    return { ...bciResult, mode: 'ai_enhanced', aiInsights: insights };
  } catch (err) {
    return { ...bciResult, mode: 'bci_only', aiInsights: null, aiError: 'AI temporarily unavailable' };
  }
};

const quickBCI = (habits, goal = null) => bci.calculateBCI(habits, goal);

module.exports = { analyze, quickBCI };
