const aiClient = require('../aiClient');

const TEMPLATES = {
  career:   { milestones: ['Research & planning','Skill building','Portfolio/projects','Apply & interview'], habits: ['Daily skill practice (30 min)','Weekly networking outreach','Monthly progress review'] },
  health:   { milestones: ['Baseline assessment','Habit formation (week 1-4)','Consistency (week 5-8)','Optimization'], habits: ['Morning exercise routine','Track nutrition daily','8 hours sleep target'] },
  learning: { milestones: ['Choose resources','Core concepts (25%)','Deep practice (50%)','Apply & teach (100%)'], habits: ['Study 30 min daily','Weekly review & notes','Practice exercises'] },
  finance:  { milestones: ['Budget audit','Reduce expenses','Build emergency fund','Invest & grow'], habits: ['Track spending daily','Weekly budget review','Monthly savings transfer'] },
  project:  { milestones: ['Planning & scope','MVP build','Testing & feedback','Launch & iterate'], habits: ['2 hours focused work daily','Weekly progress review','User feedback sessions'] },
  other:    { milestones: ['Define scope','First 25% progress','Halfway checkpoint','Complete & review'], habits: ['Daily focused action','Weekly review','Progress tracking'] }
};

const decompose = async (goal, opts = {}) => {
  const category = goal.category || 'other';

  if (!opts.useAI || !aiClient.isConfigured()) {
    const tpl = TEMPLATES[category] || TEMPLATES.other;
    return {
      mode: 'template',
      milestones: tpl.milestones.map((title, i) => ({ title, done: false, order: i + 1 })),
      suggestedHabits: tpl.habits,
      estimatedWeeks: 12,
      advice: `This is a template plan for ${category} goals. Enable AI for a personalized breakdown.`
    };
  }

  try {
    const prompt = `Break down this goal into an actionable plan. Return JSON only.

GOAL: ${goal.title}
DESCRIPTION: ${goal.description || 'None'}
CATEGORY: ${category}
TARGET DATE: ${goal.targetDate || 'Not set'}

Return this exact structure:
{
  "milestones": [{"title":"string","done":false,"order":1}, ...],
  "suggestedHabits": ["string","string","string"],
  "estimatedWeeks": 12,
  "advice": "string"
}

Rules: 4-6 milestones ordered logically, 3-4 habit suggestions, realistic timeline.`;

    const result = await aiClient.generate(prompt);
    return { ...result, mode: 'ai' };
  } catch {
    const tpl = TEMPLATES[category] || TEMPLATES.other;
    return {
      mode: 'template',
      milestones: tpl.milestones.map((title, i) => ({ title, done: false, order: i + 1 })),
      suggestedHabits: tpl.habits,
      estimatedWeeks: 12,
      advice: 'AI unavailable — using template plan. Try again for personalized results.'
    };
  }
};

module.exports = { decompose };
