const aiClient = require('../aiClient');

// ── Reflection Analyzer ─────────────────────────────────────────────────────
const analyzeReflection = async (text, opts = {}) => {
  const words = text.trim().split(/\s+/).filter(Boolean).length;

  if (!opts.useAI || !aiClient.isConfigured()) {
    const positive = ['happy','great','good','excited','motivated','proud','grateful','accomplished'].filter(w => text.toLowerCase().includes(w)).length;
    const negative = ['tired','stressed','anxious','sad','frustrated','overwhelmed','bad','difficult'].filter(w => text.toLowerCase().includes(w)).length;
    const sentiment = positive > negative ? 'positive' : negative > positive ? 'negative' : 'neutral';
    return {
      mode: 'basic',
      wordCount: words,
      sentiment,
      themes: ['Personal reflection'],
      insights: ['Enable AI for deeper psychological insights.'],
      suggestions: ['Keep journaling consistently — even 5 minutes daily builds self-awareness.']
    };
  }

  try {
    const prompt = `Analyze this journal entry. Return JSON only.

ENTRY: """${text.slice(0, 2000)}"""

Return:
{
  "themes": ["string","string","string"],
  "insights": ["string","string"],
  "suggestions": ["string","string","string"],
  "sentiment": "positive|negative|neutral|mixed",
  "emotionalPatterns": "string",
  "wordCount": ${words}
}`;
    const result = await aiClient.generate(prompt);
    return { ...result, mode: 'ai', wordCount: words };
  } catch {
    return { mode: 'basic', wordCount: words, sentiment: 'neutral', themes: [], insights: [], suggestions: ['AI unavailable. Try again later.'] };
  }
};

// ── Planning Optimizer ──────────────────────────────────────────────────────
const optimizeTasks = async (tasks, opts = {}) => {
  const PRIORITY_SCORE = { urgent: 4, high: 3, medium: 2, low: 1 };

  if (!opts.useAI || !aiClient.isConfigured()) {
    const sorted = [...tasks].sort((a, b) => {
      const ps = (PRIORITY_SCORE[b.priority] || 2) - (PRIORITY_SCORE[a.priority] || 2);
      if (ps !== 0) return ps;
      if (a.dueDate && b.dueDate) return new Date(a.dueDate) - new Date(b.dueDate);
      return a.dueDate ? -1 : b.dueDate ? 1 : 0;
    });
    return {
      mode: 'basic',
      orderedTasks: sorted.map((t, i) => ({ id: t._id, rank: i + 1, reason: `${t.priority} priority` })),
      advice: 'Basic prioritization by urgency & due date. Enable AI for smart optimization.',
      totalEstimatedHours: Math.round(tasks.reduce((s, t) => s + (t.estimatedMinutes || 30), 0) / 60 * 10) / 10
    };
  }

  try {
    const prompt = `Optimize this task list for maximum productivity. Return JSON only.

TASKS: ${JSON.stringify(tasks.map(t => ({ id: t._id, title: t.title, priority: t.priority, dueDate: t.dueDate, estimatedMinutes: t.estimatedMinutes })))}

Return:
{
  "orderedTasks": [{"id":"string","rank":1,"reason":"string"},...],
  "advice": "string",
  "totalEstimatedHours": 0,
  "suggestedSchedule": "string"
}`;
    const result = await aiClient.generate(prompt);
    return { ...result, mode: 'ai' };
  } catch {
    const sorted = [...tasks].sort((a, b) => (PRIORITY_SCORE[b.priority] || 2) - (PRIORITY_SCORE[a.priority] || 2));
    return {
      mode: 'basic',
      orderedTasks: sorted.map((t, i) => ({ id: t._id, rank: i + 1, reason: `${t.priority} priority` })),
      advice: 'AI unavailable — using basic prioritization.'
    };
  }
};

module.exports = { analyzeReflection, optimizeTasks };
