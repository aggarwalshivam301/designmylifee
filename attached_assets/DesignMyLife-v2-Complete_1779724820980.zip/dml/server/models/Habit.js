const mongoose = require('mongoose');

const completionSchema = new mongoose.Schema({
  date:      { type: Date, required: true },
  completed: { type: Boolean, default: true }
}, { _id: false });

const habitSchema = new mongoose.Schema({
  user:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name:        { type: String, required: true, trim: true },
  description: { type: String, trim: true, default: '' },
  frequency:   { type: String, enum: ['daily', 'weekly'], default: 'daily' },
  goalId:      { type: mongoose.Schema.Types.ObjectId, ref: 'Goal', default: null },
  currentStreak:  { type: Number, default: 0 },
  longestStreak:  { type: Number, default: 0 },
  completionHistory: [completionSchema],
  isActive:    { type: Boolean, default: true },
  createdAt:   { type: Date, default: Date.now }
});

habitSchema.methods.updateStreak = function () {
  const history = this.completionHistory
    .filter(c => c.completed)
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  if (!history.length) { this.currentStreak = 0; return; }

  let streak = 0;
  const today = new Date(); today.setHours(0, 0, 0, 0);

  for (let i = 0; i < history.length; i++) {
    const d = new Date(history[i].date); d.setHours(0, 0, 0, 0);
    const expected = new Date(today); expected.setDate(today.getDate() - i);
    if (d.getTime() === expected.getTime()) streak++;
    else break;
  }
  this.currentStreak = streak;
  if (streak > this.longestStreak) this.longestStreak = streak;
};

module.exports = mongoose.model('Habit', habitSchema);
