const mongoose = require('mongoose');

const milestoneSchema = new mongoose.Schema({
  title:     { type: String, required: true },
  done:      { type: Boolean, default: false },
  dueDate:   { type: Date }
}, { _id: true });

const goalSchema = new mongoose.Schema({
  user:         { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title:        { type: String, required: true, trim: true },
  description:  { type: String, trim: true, default: '' },
  category:     { type: String, enum: ['career','health','learning','finance','relationships','project','other'], default: 'other' },
  targetDate:   { type: Date },
  progress:     { type: Number, default: 0, min: 0, max: 100 },
  status:       { type: String, enum: ['active','completed','paused'], default: 'active' },
  linkedHabits: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Habit' }],
  linkedTasks:  [{ type: mongoose.Schema.Types.ObjectId, ref: 'Task' }],
  milestones:   [milestoneSchema],
  aiDecomposed: { type: Boolean, default: false },
  createdAt:    { type: Date, default: Date.now }
});

module.exports = mongoose.model('Goal', goalSchema);
