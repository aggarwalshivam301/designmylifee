const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  user:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title:       { type: String, required: true, trim: true },
  description: { type: String, trim: true, default: '' },
  priority:    { type: String, enum: ['low','medium','high','urgent'], default: 'medium' },
  status:      { type: String, enum: ['todo','in-progress','completed'], default: 'todo' },
  dueDate:     { type: Date },
  goalId:      { type: mongoose.Schema.Types.ObjectId, ref: 'Goal', default: null },
  completedAt: { type: Date },
  estimatedMinutes: { type: Number, default: 30 },
  createdAt:   { type: Date, default: Date.now }
});

module.exports = mongoose.model('Task', taskSchema);
