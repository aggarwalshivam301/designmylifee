const mongoose = require('mongoose');

const journalSchema = new mongoose.Schema({
  user:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title:      { type: String, trim: true, default: '' },
  content:    { type: String, required: true },
  mood:       { type: String, enum: ['great','good','okay','bad','awful'], default: 'okay' },
  tags:       [{ type: String, trim: true }],
  wordCount:  { type: Number, default: 0 },
  aiAnalysis: {
    themes:       [String],
    insights:     [String],
    suggestions:  [String],
    sentiment:    { type: String, default: '' },
    analyzedAt:   { type: Date }
  },
  createdAt:  { type: Date, default: Date.now },
  updatedAt:  { type: Date, default: Date.now }
});

journalSchema.pre('save', function (next) {
  this.wordCount = this.content.trim().split(/\s+/).filter(Boolean).length;
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('JournalEntry', journalSchema);
