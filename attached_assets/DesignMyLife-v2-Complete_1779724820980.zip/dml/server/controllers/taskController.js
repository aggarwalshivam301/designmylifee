const Task = require('../models/Task');

const getTasks = async (req, res) => {
  try {
    const filter = { user: req.user._id };
    if (req.query.status) filter.status = req.query.status;
    if (req.query.priority) filter.priority = req.query.priority;
    const tasks = await Task.find(filter).populate('goalId', 'title').sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const getTodayTasks = async (req, res) => {
  try {
    const today = new Date(); today.setHours(0,0,0,0);
    const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
    const tasks = await Task.find({
      user: req.user._id,
      status: { $ne: 'completed' },
      $or: [
        { dueDate: { $gte: today, $lt: tomorrow } },
        { dueDate: null }
      ]
    }).populate('goalId', 'title').sort({ priority: -1 });
    res.json(tasks);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const createTask = async (req, res) => {
  try {
    const { title, description, priority, dueDate, goalId, estimatedMinutes } = req.body;
    if (!title) return res.status(400).json({ message: 'Task title is required' });
    const task = await Task.create({
      user: req.user._id, title, description, priority,
      dueDate: dueDate || null, goalId: goalId || null, estimatedMinutes
    });
    res.status(201).json(task);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const updateTask = async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ message: 'Task not found' });
    const allowed = ['title','description','priority','status','dueDate','goalId','estimatedMinutes'];
    allowed.forEach(k => { if (req.body[k] !== undefined) task[k] = req.body[k]; });
    if (req.body.status === 'completed' && !task.completedAt) task.completedAt = new Date();
    await task.save();
    res.json(task);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const deleteTask = async (req, res) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json({ message: 'Task deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

module.exports = { getTasks, getTodayTasks, createTask, updateTask, deleteTask };
