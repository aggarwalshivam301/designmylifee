const Habit = require('../models/Habit');

const getHabits = async (req, res) => {
  try {
    const habits = await Habit.find({ user: req.user._id, isActive: true })
      .populate('goalId', 'title').sort({ createdAt: -1 });
    res.json(habits);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const createHabit = async (req, res) => {
  try {
    const { name, description, frequency, goalId } = req.body;
    if (!name) return res.status(400).json({ message: 'Habit name is required' });
    const habit = await Habit.create({
      user: req.user._id, name, description, frequency, goalId: goalId || null
    });
    res.status(201).json(habit);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const updateHabit = async (req, res) => {
  try {
    const habit = await Habit.findOne({ _id: req.params.id, user: req.user._id });
    if (!habit) return res.status(404).json({ message: 'Habit not found' });
    const { name, description, frequency, goalId } = req.body;
    if (name) habit.name = name;
    if (description !== undefined) habit.description = description;
    if (frequency) habit.frequency = frequency;
    if (goalId !== undefined) habit.goalId = goalId || null;
    await habit.save();
    res.json(habit);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const deleteHabit = async (req, res) => {
  try {
    const habit = await Habit.findOne({ _id: req.params.id, user: req.user._id });
    if (!habit) return res.status(404).json({ message: 'Habit not found' });
    habit.isActive = false;
    await habit.save();
    res.json({ message: 'Habit deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const checkIn = async (req, res) => {
  try {
    const habit = await Habit.findOne({ _id: req.params.id, user: req.user._id });
    if (!habit) return res.status(404).json({ message: 'Habit not found' });

    const today = new Date(); today.setHours(0, 0, 0, 0);
    const alreadyDone = habit.completionHistory.some(c => {
      const d = new Date(c.date); d.setHours(0, 0, 0, 0);
      return d.getTime() === today.getTime() && c.completed;
    });

    if (!alreadyDone) {
      habit.completionHistory.push({ date: today, completed: true });
      habit.updateStreak();
      await habit.save();
    }
    res.json(habit);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const getStats = async (req, res) => {
  try {
    const habit = await Habit.findOne({ _id: req.params.id, user: req.user._id });
    if (!habit) return res.status(404).json({ message: 'Habit not found' });

    const now = Date.now();
    const completed = habit.completionHistory.filter(c => c.completed);
    const last7  = completed.filter(c => (now - new Date(c.date)) / 86400000 <= 7).length;
    const last30 = completed.filter(c => (now - new Date(c.date)) / 86400000 <= 30).length;

    res.json({
      currentStreak: habit.currentStreak,
      longestStreak: habit.longestStreak,
      totalCompletions: completed.length,
      last7Days: last7,
      last30Days: last30,
      completionRate7:  Math.round((last7 / 7) * 100),
      completionRate30: Math.round((last30 / 30) * 100),
      recentHistory: habit.completionHistory.slice(-30)
    });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

module.exports = { getHabits, createHabit, updateHabit, deleteHabit, checkIn, getStats };
