const aiClient        = require('../ai/aiClient');
const behaviorAnalyzer = require('../ai/modules/behaviorAnalyzer');
const goalDecomposer   = require('../ai/modules/goalDecomposer');
const { analyzeReflection, optimizeTasks } = require('../ai/modules/reflectionAnalyzer');
const Habit  = require('../models/Habit');
const Goal   = require('../models/Goal');
const Task   = require('../models/Task');

// GET /api/ai/status
const getStatus = async (req, res) => {
  res.json({
    configured: aiClient.isConfigured(),
    provider:   process.env.AI_PROVIDER || 'none',
    model:      process.env.AI_MODEL    || 'none',
    userEnabled: req.user.aiEnabled
  });
};

// POST /api/ai/analyze-behavior
const analyzeBehavior = async (req, res) => {
  try {
    const { useAI = true, goalId } = req.body;
    const habits = await Habit.find({ user: req.user._id, isActive: true });
    const goal   = goalId ? await Goal.findById(goalId) : null;
    const result = await behaviorAnalyzer.analyze(habits, { useAI: useAI && req.user.aiEnabled, goal });
    res.json(result);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// POST /api/ai/quick-bci
const quickBCI = async (req, res) => {
  try {
    const { goalId } = req.body;
    const habits = await Habit.find({ user: req.user._id, isActive: true });
    const goal   = goalId ? await Goal.findById(goalId) : null;
    res.json(behaviorAnalyzer.quickBCI(habits, goal));
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// POST /api/ai/decompose-goal
const decomposeGoal = async (req, res) => {
  try {
    const { goalId, useAI = true } = req.body;
    const goal = await Goal.findOne({ _id: goalId, user: req.user._id });
    if (!goal) return res.status(404).json({ message: 'Goal not found' });
    const result = await goalDecomposer.decompose(goal, { useAI: useAI && req.user.aiEnabled });
    res.json(result);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// POST /api/ai/analyze-reflection
const analyzeReflectionEntry = async (req, res) => {
  try {
    const { text, useAI = true } = req.body;
    if (!text) return res.status(400).json({ message: 'Text is required' });
    const result = await analyzeReflection(text, { useAI: useAI && req.user.aiEnabled });
    res.json(result);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// POST /api/ai/optimize-tasks
const optimizeTaskList = async (req, res) => {
  try {
    const { useAI = true } = req.body;
    const tasks = await Task.find({ user: req.user._id, status: { $ne: 'completed' } });
    const result = await optimizeTasks(tasks, { useAI: useAI && req.user.aiEnabled });
    res.json(result);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

module.exports = { getStatus, analyzeBehavior, quickBCI, decomposeGoal, analyzeReflectionEntry, optimizeTaskList };
