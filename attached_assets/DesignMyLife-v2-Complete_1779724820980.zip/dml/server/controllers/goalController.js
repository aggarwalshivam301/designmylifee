const Goal = require('../models/Goal');

const getGoals = async (req, res) => {
  try {
    const goals = await Goal.find({ user: req.user._id })
      .populate('linkedHabits', 'name currentStreak')
      .populate('linkedTasks', 'title status')
      .sort({ createdAt: -1 });
    res.json(goals);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const createGoal = async (req, res) => {
  try {
    const { title, description, category, targetDate } = req.body;
    if (!title) return res.status(400).json({ message: 'Goal title is required' });
    const goal = await Goal.create({
      user: req.user._id, title, description, category,
      targetDate: targetDate || null
    });
    res.status(201).json(goal);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const updateGoal = async (req, res) => {
  try {
    const goal = await Goal.findOne({ _id: req.params.id, user: req.user._id });
    if (!goal) return res.status(404).json({ message: 'Goal not found' });
    const allowed = ['title','description','category','targetDate','progress','status','milestones'];
    allowed.forEach(k => { if (req.body[k] !== undefined) goal[k] = req.body[k]; });
    await goal.save();
    res.json(goal);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const deleteGoal = async (req, res) => {
  try {
    const goal = await Goal.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!goal) return res.status(404).json({ message: 'Goal not found' });
    res.json({ message: 'Goal deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const linkHabit = async (req, res) => {
  try {
    const goal = await Goal.findOne({ _id: req.params.id, user: req.user._id });
    if (!goal) return res.status(404).json({ message: 'Goal not found' });
    const { habitId } = req.body;
    if (!goal.linkedHabits.includes(habitId)) goal.linkedHabits.push(habitId);
    await goal.save();
    res.json(goal);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const unlinkHabit = async (req, res) => {
  try {
    const goal = await Goal.findOne({ _id: req.params.id, user: req.user._id });
    if (!goal) return res.status(404).json({ message: 'Goal not found' });
    goal.linkedHabits = goal.linkedHabits.filter(h => h.toString() !== req.params.habitId);
    await goal.save();
    res.json(goal);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const setMilestones = async (req, res) => {
  try {
    const goal = await Goal.findOne({ _id: req.params.id, user: req.user._id });
    if (!goal) return res.status(404).json({ message: 'Goal not found' });
    goal.milestones = req.body.milestones;
    goal.aiDecomposed = true;
    await goal.save();
    res.json(goal);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

module.exports = { getGoals, createGoal, updateGoal, deleteGoal, linkHabit, unlinkHabit, setMilestones };
