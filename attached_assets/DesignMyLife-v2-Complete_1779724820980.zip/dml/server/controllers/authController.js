const jwt = require('jsonwebtoken');
const User = require('../models/User');

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });

// POST /api/auth/register
const register = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password)
      return res.status(400).json({ message: 'All fields are required' });
    if (password.length < 6)
      return res.status(400).json({ message: 'Password must be at least 6 characters' });
    if (await User.findOne({ email }))
      return res.status(400).json({ message: 'Email already in use' });

    const user = await User.create({ name, email, password });
    res.status(201).json({ token: signToken(user._id), user: sanitize(user) });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// POST /api/auth/login
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.matchPassword(password)))
      return res.status(401).json({ message: 'Invalid email or password' });
    res.json({ token: signToken(user._id), user: sanitize(user) });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// GET /api/auth/profile
const getProfile = async (req, res) => {
  res.json(sanitize(req.user));
};

// PUT /api/auth/profile
const updateProfile = async (req, res) => {
  try {
    const { name, avatar } = req.body;
    const user = await User.findByIdAndUpdate(
      req.user._id, { name, avatar }, { new: true, runValidators: true }
    ).select('-password');
    res.json(sanitize(user));
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// PUT /api/auth/change-password
const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!newPassword || newPassword.length < 6)
      return res.status(400).json({ message: 'New password must be at least 6 characters' });
    const user = await User.findById(req.user._id);
    if (!(await user.matchPassword(currentPassword)))
      return res.status(401).json({ message: 'Current password is incorrect' });
    user.password = newPassword;
    await user.save();
    res.json({ message: 'Password updated successfully' });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// PUT /api/auth/toggle-ai
const toggleAI = async (req, res) => {
  try {
    const { aiEnabled } = req.body;
    const user = await User.findByIdAndUpdate(
      req.user._id, { aiEnabled }, { new: true }
    ).select('-password');
    res.json(sanitize(user));
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const sanitize = (user) => ({
  _id: user._id, name: user.name, email: user.email,
  avatar: user.avatar, aiEnabled: user.aiEnabled, createdAt: user.createdAt
});

module.exports = { register, login, getProfile, updateProfile, changePassword, toggleAI };
