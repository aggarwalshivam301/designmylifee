const JournalEntry = require('../models/JournalEntry');

const getEntries = async (req, res) => {
  try {
    const entries = await JournalEntry.find({ user: req.user._id })
      .sort({ createdAt: -1 }).limit(50);
    res.json(entries);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const getEntry = async (req, res) => {
  try {
    const entry = await JournalEntry.findOne({ _id: req.params.id, user: req.user._id });
    if (!entry) return res.status(404).json({ message: 'Entry not found' });
    res.json(entry);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const createEntry = async (req, res) => {
  try {
    const { title, content, mood, tags } = req.body;
    if (!content) return res.status(400).json({ message: 'Content is required' });
    const entry = await JournalEntry.create({
      user: req.user._id, title, content, mood, tags: tags || []
    });
    res.status(201).json(entry);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const updateEntry = async (req, res) => {
  try {
    const entry = await JournalEntry.findOne({ _id: req.params.id, user: req.user._id });
    if (!entry) return res.status(404).json({ message: 'Entry not found' });
    const { title, content, mood, tags } = req.body;
    if (title !== undefined) entry.title = title;
    if (content) entry.content = content;
    if (mood) entry.mood = mood;
    if (tags) entry.tags = tags;
    await entry.save();
    res.json(entry);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const deleteEntry = async (req, res) => {
  try {
    const entry = await JournalEntry.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!entry) return res.status(404).json({ message: 'Entry not found' });
    res.json({ message: 'Entry deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

const saveAIAnalysis = async (req, res) => {
  try {
    const entry = await JournalEntry.findOne({ _id: req.params.id, user: req.user._id });
    if (!entry) return res.status(404).json({ message: 'Entry not found' });
    entry.aiAnalysis = { ...req.body.analysis, analyzedAt: new Date() };
    await entry.save();
    res.json(entry);
  } catch (err) { res.status(500).json({ message: err.message }); }
};

module.exports = { getEntries, getEntry, createEntry, updateEntry, deleteEntry, saveAIAnalysis };
