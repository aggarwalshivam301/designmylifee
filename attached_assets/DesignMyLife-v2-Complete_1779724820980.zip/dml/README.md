# ✦ DesignMyLife — Full Stack Life OS

A complete MERN stack productivity app with BCI scoring, AI integration, and a toggle to run fully without AI.

---

## 🚀 Quick Start (5 minutes)

### Prerequisites
- Node.js v18+
- MongoDB Atlas account (free at [mongodb.com/atlas](https://www.mongodb.com/atlas))
- Git

---

### Step 1 — Clone & Install

```bash
# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

---

### Step 2 — Configure Server Environment

```bash
cd server
cp .env.example .env
```

Open `server/.env` and fill in:

```env
PORT=5000
MONGO_URI=mongodb+srv://USERNAME:PASSWORD@cluster.mongodb.net/designmylife
JWT_SECRET=any_long_random_string_here_32_chars_min

# ── AI (Optional) ──────────────────────────────
# Leave AI_API_KEY blank to run WITHOUT AI — BCI still works!
AI_PROVIDER=anthropic
AI_API_KEY=
AI_MODEL=claude-3-5-sonnet-20241022
```

**Getting your MongoDB URI:**
1. Go to [mongodb.com/atlas](https://www.mongodb.com/atlas) → Create free cluster
2. Click **Connect** → **Connect your application**
3. Copy the URI and replace `<username>` and `<password>`

---

### Step 3 — Configure Client Environment

```bash
cd client
cp .env.example .env
```

`client/.env` should contain:
```env
VITE_API_URL=http://localhost:5000/api
```

---

### Step 4 — Run the App

Open **two terminals**:

```bash
# Terminal 1 — Backend
cd server
npm run dev

# Terminal 2 — Frontend
cd client
npm run dev
```

Open **http://localhost:5173** — you're live!

---

## 🤖 AI Toggle Guide

### Running WITHOUT AI (Default)
The app runs perfectly without any AI API key. You still get:
- ✅ BCI Score with full breakdown (S×0.4 + C×0.3 + T×0.2 + G×0.1)
- ✅ Goal milestone templates by category
- ✅ Task sorting by priority & due date
- ✅ Journal basic sentiment analysis
- ✅ All CRUD features fully working

### Enabling AI
1. Get a free API key from [console.anthropic.com](https://console.anthropic.com)
2. Add to `server/.env`:
   ```env
   AI_API_KEY=sk-ant-your-key-here
   ```
3. Restart the server
4. Toggle AI **ON** in the sidebar (or in Settings)

### AI Toggle Behaviour
- **Global toggle** in sidebar — turns all AI features on/off instantly
- **Per-page buttons** — each page has its own "Analyze with AI" button
- **Always visible** — the BCI and AI sections always show; they adapt based on mode
- **Graceful fallback** — if AI fails, falls back to math-only BCI silently

---

## 📁 Project Structure

```
designmylife/
├── server/                    # Express + MongoDB backend
│   ├── controllers/           # Route handlers
│   ├── models/                # Mongoose models
│   ├── routes/                # API routes
│   ├── middleware/            # Auth middleware
│   ├── services/
│   │   └── bciCalculator.js   # BCI algorithm (pure math)
│   └── ai/
│       ├── aiClient.js        # Anthropic/OpenAI wrapper
│       └── modules/           # AI feature modules
│           ├── behaviorAnalyzer.js
│           ├── goalDecomposer.js
│           └── reflectionAnalyzer.js  # Also contains planningOptimizer
└── client/                    # React + Vite + Tailwind frontend
    └── src/
        ├── context/
        │   ├── AuthContext.jsx    # Auth state + JWT
        │   └── AIContext.jsx      # Global AI toggle state
        ├── api/
        │   └── apiClient.js       # All API calls
        ├── components/
        │   ├── Sidebar.jsx        # Nav + global AI toggle
        │   ├── Layout.jsx
        │   └── BCIDisplay.jsx     # BCI visualization
        └── pages/
            ├── Dashboard.jsx
            ├── Habits.jsx         # Habit tracker + BCI + AI toggle
            ├── Goals.jsx          # Goals + AI decomposition
            ├── Tasks.jsx          # Tasks + AI prioritization
            ├── Analytics.jsx      # Charts & stats
            ├── Journal.jsx        # Journal + AI reflection
            ├── Focus.jsx          # Pomodoro timer
            └── Settings.jsx       # Profile + AI config
```

---

## 🧮 BCI Algorithm

```
BCI = (S × 0.4) + (C × 0.3) + (T × 0.2) + (G × 0.1)
```

| Component | Weight | Measures |
|-----------|--------|----------|
| S — Streak Consistency  | 40% | How well you maintain daily streaks |
| C — Completion Rate     | 30% | % of habits completed in last 30 days |
| T — Time Consistency    | 20% | How regular your completion times are |
| G — Goal Alignment      | 10% | How well habits connect to goals |

**Success Probability** uses a logistic function:
```
P = 1 / (1 + e^(-(BCI - 50) / 10)) × 100%
```

---

## 🛠 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Sign in |
| GET  | `/api/auth/profile` | Get profile |
| PUT  | `/api/auth/toggle-ai` | Toggle AI on/off |
| GET  | `/api/habits` | Get all habits |
| POST | `/api/habits` | Create habit |
| POST | `/api/habits/:id/checkin` | Check in today |
| GET  | `/api/goals` | Get all goals |
| POST | `/api/goals` | Create goal |
| PUT  | `/api/goals/:id/milestones` | Save milestones |
| GET  | `/api/tasks` | Get all tasks |
| POST | `/api/tasks` | Create task |
| GET  | `/api/journal` | Get journal entries |
| POST | `/api/journal` | Create entry |
| GET  | `/api/ai/status` | AI availability check |
| POST | `/api/ai/quick-bci` | BCI score (no AI) |
| POST | `/api/ai/analyze-behavior` | BCI + optional AI insights |
| POST | `/api/ai/decompose-goal` | Goal → milestones |
| POST | `/api/ai/analyze-reflection` | Journal AI analysis |
| POST | `/api/ai/optimize-tasks` | Task prioritization |

---

## 🌐 Deployment

### Backend (Render / Railway)
1. Push `server/` to GitHub
2. Set environment variables on the platform
3. Build command: `npm install`, Start: `node server.js`

### Frontend (Vercel / Netlify)
1. Push `client/` to GitHub
2. Set `VITE_API_URL=https://your-backend.render.com/api`
3. Build: `npm run build`, Output: `dist`

---

## 🐛 Troubleshooting

| Problem | Fix |
|---------|-----|
| `MONGO_URI` connection error | Check Atlas IP whitelist — add `0.0.0.0/0` |
| 401 Unauthorized on API calls | Token expired — log out and back in |
| AI not working | Check `AI_API_KEY` in `.env`, restart server |
| Blank page on client | Check `VITE_API_URL` in `client/.env` |
| Port 5000 in use | Change `PORT=5001` in `server/.env` |

---

## 🎓 Academic Note (for B.Tech report)

This project implements the **Behavioral Consistency Index (BCI)** as its core academic contribution — a novel quantitative metric for measuring behavioral consistency across multiple life dimensions, computed using weighted components and logistic regression for success prediction.

Built with: React 18 · Express 4 · MongoDB Atlas · Tailwind CSS · Recharts · Anthropic Claude API

---

*DesignMyLife v2.0 — Built by Shiv Kumar, B.Tech CSE, IIMT University Meerut, 2026*
