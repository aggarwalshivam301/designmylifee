import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const API = import.meta.env.VITE_API_URL || '/api';
const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(() => { try { return JSON.parse(localStorage.getItem('dml_user')); } catch { return null; } });
  const [token, setToken]     = useState(() => localStorage.getItem('dml_token') || null);
  const [loading, setLoading] = useState(true);

  // Axios default header
  useEffect(() => {
    if (token) axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    else delete axios.defaults.headers.common['Authorization'];
  }, [token]);

  // Verify token on mount
  useEffect(() => {
    const verify = async () => {
      if (!token) { setLoading(false); return; }
      try {
        const { data } = await axios.get(`${API}/auth/profile`);
        persist(token, data);
      } catch { logout(); }
      finally { setLoading(false); }
    };
    verify();
  }, []); // eslint-disable-line

  const persist = (tk, u) => {
    setToken(tk); setUser(u);
    localStorage.setItem('dml_token', tk);
    localStorage.setItem('dml_user',  JSON.stringify(u));
    axios.defaults.headers.common['Authorization'] = `Bearer ${tk}`;
  };

  const login = async (email, password) => {
    const { data } = await axios.post(`${API}/auth/login`, { email, password });
    persist(data.token, data.user);
    return data.user;
  };

  const register = async (name, email, password) => {
    const { data } = await axios.post(`${API}/auth/register`, { name, email, password });
    persist(data.token, data.user);
    return data.user;
  };

  const logout = () => {
    setToken(null); setUser(null);
    localStorage.removeItem('dml_token');
    localStorage.removeItem('dml_user');
    delete axios.defaults.headers.common['Authorization'];
  };

  const updateUser = useCallback((updates) => {
    setUser(prev => {
      const next = { ...prev, ...updates };
      localStorage.setItem('dml_user', JSON.stringify(next));
      return next;
    });
  }, []);

  const refreshProfile = async () => {
    try { const { data } = await axios.get(`${API}/auth/profile`); updateUser(data); } catch {}
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout, updateUser, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
};
