import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

const API = import.meta.env.VITE_API_URL || '/api';
const AIContext = createContext(null);

export function AIProvider({ children }) {
  const { user, updateUser } = useAuth();
  const [aiEnabled,   setAiEnabled]   = useState(user?.aiEnabled ?? false);
  const [aiConfigured, setAiConfigured] = useState(false);  // API key set on server?
  const [checkingAI,  setCheckingAI]  = useState(false);

  // Sync with user object
  useEffect(() => { if (user) setAiEnabled(user.aiEnabled ?? false); }, [user]);

  // Check server AI config once on mount
  useEffect(() => {
    checkAIStatus();
  }, []); // eslint-disable-line

  const checkAIStatus = async () => {
    setCheckingAI(true);
    try {
      const { data } = await axios.get(`${API}/ai/status`);
      setAiConfigured(data.configured);
    } catch { setAiConfigured(false); }
    finally { setCheckingAI(false); }
  };

  const toggleAI = useCallback(async () => {
    const next = !aiEnabled;
    setAiEnabled(next); // Optimistic
    try {
      const { data } = await axios.put(`${API}/auth/toggle-ai`, { aiEnabled: next });
      updateUser({ aiEnabled: data.aiEnabled });
    } catch {
      setAiEnabled(!next); // Revert on error
    }
  }, [aiEnabled, updateUser]);

  const setAI = useCallback(async (val) => {
    if (val === aiEnabled) return;
    setAiEnabled(val);
    try {
      const { data } = await axios.put(`${API}/auth/toggle-ai`, { aiEnabled: val });
      updateUser({ aiEnabled: data.aiEnabled });
    } catch { setAiEnabled(!val); }
  }, [aiEnabled, updateUser]);

  // effective = user has AI on AND server has API key configured
  const aiEffective = aiEnabled && aiConfigured;

  return (
    <AIContext.Provider value={{ aiEnabled, aiConfigured, aiEffective, toggleAI, setAI, checkAIStatus, checkingAI }}>
      {children}
    </AIContext.Provider>
  );
}

export const useAI = () => {
  const ctx = useContext(AIContext);
  if (!ctx) throw new Error('useAI must be used inside AIProvider');
  return ctx;
};
