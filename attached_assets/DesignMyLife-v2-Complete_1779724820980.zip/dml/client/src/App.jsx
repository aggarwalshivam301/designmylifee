import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AIProvider } from './context/AIContext';
import Layout   from './components/Layout';
import Login    from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Habits   from './pages/Habits';
import Goals    from './pages/Goals';
import Tasks    from './pages/Tasks';
import Analytics from './pages/Analytics';
import Journal  from './pages/Journal';
import Focus    from './pages/Focus';
import Settings from './pages/Settings';

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#f8f7ff]">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-700 to-blue-600 flex items-center justify-center text-white text-xl">✦</div>
        <p className="text-gray-400 text-sm">Loading...</p>
      </div>
    </div>
  );
  return user ? children : <Navigate to="/login" replace />;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login"    element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to="/" replace /> : <Register />} />
      <Route path="/" element={<Protected><AIProvider><Layout /></AIProvider></Protected>}>
        <Route index              element={<Dashboard />} />
        <Route path="habits"      element={<Habits />} />
        <Route path="goals"       element={<Goals />} />
        <Route path="tasks"       element={<Tasks />} />
        <Route path="analytics"   element={<Analytics />} />
        <Route path="journal"     element={<Journal />} />
        <Route path="focus"       element={<Focus />} />
        <Route path="settings"    element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
