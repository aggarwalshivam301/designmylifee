import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Loader2 } from 'lucide-react';

export default function Register() {
  const { register }     = useAuth();
  const navigate         = useNavigate();
  const [form, setForm]  = useState({ name: '', email: '', password: '', confirm: '' });
  const [error, setError]= useState('');
  const [loading, setLoading] = useState(false);

  const handle = async e => {
    e.preventDefault(); setError('');
    if (form.password !== form.confirm) return setError('Passwords do not match');
    if (form.password.length < 6) return setError('Password must be at least 6 characters');
    setLoading(true);
    try { await register(form.name, form.email, form.password); navigate('/'); }
    catch (err) { setError(err.response?.data?.message || 'Registration failed'); }
    finally { setLoading(false); }
  };

  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#f8f7ff] to-[#eff6ff] p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary-700 to-blue-600 flex items-center justify-center text-white text-3xl mx-auto mb-4">✦</div>
          <h1 className="text-2xl font-black text-gray-900">Start designing your life</h1>
          <p className="text-gray-500 text-sm mt-1">Create your free DesignMyLife account</p>
        </div>
        <div className="card shadow-xl shadow-primary-100/50">
          {error && <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-100 text-red-600 text-sm">{error}</div>}
          <form onSubmit={handle} className="space-y-4">
            <div>
              <label className="label">Full Name</label>
              <input className="input" placeholder="Shiv Kumar" value={form.name} onChange={e => f('name', e.target.value)} required />
            </div>
            <div>
              <label className="label">Email</label>
              <input className="input" type="email" placeholder="you@example.com" value={form.email} onChange={e => f('email', e.target.value)} required />
            </div>
            <div>
              <label className="label">Password</label>
              <input className="input" type="password" placeholder="Min 6 characters" value={form.password} onChange={e => f('password', e.target.value)} required />
            </div>
            <div>
              <label className="label">Confirm Password</label>
              <input className="input" type="password" placeholder="Repeat password" value={form.confirm} onChange={e => f('confirm', e.target.value)} required />
            </div>
            <button className="btn-primary w-full justify-center py-2.5 mt-2" disabled={loading}>
              {loading ? <><Loader2 size={16} className="animate-spin" />Creating account...</> : 'Create Account'}
            </button>
          </form>
          <p className="text-center text-sm text-gray-500 mt-5">Already have an account? <Link to="/login" className="text-primary-700 font-semibold hover:underline">Sign in</Link></p>
        </div>
      </div>
    </div>
  );
}
