import { useState, useEffect } from 'react';
import { User, Lock, Zap, Check, Loader2, AlertCircle, ExternalLink } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAI }   from '../context/AIContext';
import { authAPI, aiAPI } from '../api/apiClient';

function Section({ title, icon: Icon, children }) {
  return (
    <div className="card mb-5">
      <div className="flex items-center gap-2 mb-5 pb-4 border-b border-gray-100">
        <div className="w-8 h-8 rounded-lg bg-primary-50 flex items-center justify-center">
          <Icon size={15} className="text-primary-700" />
        </div>
        <h2 className="font-bold text-gray-800">{title}</h2>
      </div>
      {children}
    </div>
  );
}

export default function Settings() {
  const { user, updateUser } = useAuth();
  const { aiEnabled, aiConfigured, aiEffective, toggleAI, checkAIStatus } = useAI();

  const [profile, setProfile] = useState({ name: user?.name || '', email: user?.email || '' });
  const [passwords, setPasswords] = useState({ current:'', newPass:'', confirm:'' });
  const [saving,  setSaving]  = useState('');
  const [msg,     setMsg]     = useState({ type:'', text:'' });
  const [aiStatus, setAiStatus] = useState(null);
  const [testing,  setTesting]  = useState(false);

  useEffect(() => { loadAIStatus(); }, []); // eslint-disable-line

  const loadAIStatus = async () => {
    try { const { data } = await aiAPI.getStatus(); setAiStatus(data); } catch {}
  };

  const flash = (type, text) => { setMsg({ type, text }); setTimeout(() => setMsg({ type:'', text:'' }), 3500); };

  const saveProfile = async e => {
    e.preventDefault(); setSaving('profile');
    try {
      const { data } = await authAPI.updateProfile({ name: profile.name });
      updateUser(data); flash('success', 'Profile updated successfully!');
    } catch (err) { flash('error', err.response?.data?.message || 'Update failed'); }
    finally { setSaving(''); }
  };

  const changePassword = async e => {
    e.preventDefault();
    if (passwords.newPass !== passwords.confirm) return flash('error', 'New passwords do not match');
    if (passwords.newPass.length < 6) return flash('error', 'Password must be at least 6 characters');
    setSaving('password');
    try {
      await authAPI.changePassword({ currentPassword: passwords.current, newPassword: passwords.newPass });
      setPasswords({ current:'', newPass:'', confirm:'' });
      flash('success', 'Password changed successfully!');
    } catch (err) { flash('error', err.response?.data?.message || 'Password change failed'); }
    finally { setSaving(''); }
  };

  const testAI = async () => {
    setTesting(true);
    try {
      await checkAIStatus(); await loadAIStatus();
      flash('success', 'AI connection is working!');
    } catch { flash('error', 'AI connection failed. Check your API key in .env'); }
    finally { setTesting(false); }
  };

  return (
    <div className="p-8 max-w-2xl">
      <div className="mb-8">
        <h1 className="text-3xl font-black text-gray-900">Settings</h1>
        <p className="text-gray-500 text-sm mt-1">Manage your account and AI configuration</p>
      </div>

      {/* Flash message */}
      {msg.text && (
        <div className={`mb-5 p-3 rounded-xl text-sm flex items-center gap-2 ${msg.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {msg.type === 'success' ? <Check size={14}/> : <AlertCircle size={14}/>} {msg.text}
        </div>
      )}

      {/* Profile */}
      <Section title="Profile" icon={User}>
        <form onSubmit={saveProfile} className="space-y-4">
          <div>
            <label className="label">Full Name</label>
            <input className="input" value={profile.name} onChange={e => setProfile(p=>({...p,name:e.target.value}))} required />
          </div>
          <div>
            <label className="label">Email Address</label>
            <input className="input" value={profile.email} disabled
              style={{ opacity: 0.6, cursor: 'not-allowed' }} />
            <p className="text-[10px] text-gray-400 mt-1">Email cannot be changed after registration</p>
          </div>
          <button className="btn-primary" disabled={saving==='profile'}>
            {saving==='profile' ? <><Loader2 size={14} className="animate-spin"/>Saving...</> : <><Check size={14}/>Save Profile</>}
          </button>
        </form>
      </Section>

      {/* Password */}
      <Section title="Change Password" icon={Lock}>
        <form onSubmit={changePassword} className="space-y-4">
          <div>
            <label className="label">Current Password</label>
            <input className="input" type="password" placeholder="Enter current password"
              value={passwords.current} onChange={e=>setPasswords(p=>({...p,current:e.target.value}))} required />
          </div>
          <div>
            <label className="label">New Password</label>
            <input className="input" type="password" placeholder="Min 6 characters"
              value={passwords.newPass} onChange={e=>setPasswords(p=>({...p,newPass:e.target.value}))} required />
          </div>
          <div>
            <label className="label">Confirm New Password</label>
            <input className="input" type="password" placeholder="Repeat new password"
              value={passwords.confirm} onChange={e=>setPasswords(p=>({...p,confirm:e.target.value}))} required />
          </div>
          <button className="btn-primary" disabled={saving==='password'}>
            {saving==='password' ? <><Loader2 size={14} className="animate-spin"/>Updating...</> : <><Lock size={14}/>Change Password</>}
          </button>
        </form>
      </Section>

      {/* AI Configuration */}
      <Section title="AI Configuration" icon={Zap}>
        {/* Global toggle */}
        <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 border border-gray-200 mb-5">
          <div>
            <p className="font-semibold text-gray-800 text-sm">AI Features Globally</p>
            <p className="text-xs text-gray-500 mt-0.5">
              {aiEnabled ? 'AI-powered insights are enabled' : 'Using BCI math only — no AI calls'}
            </p>
          </div>
          <button onClick={toggleAI}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-300 focus:outline-none ${aiEnabled ? 'bg-primary-600' : 'bg-gray-300'}`}>
            <span className={`inline-block h-4 w-4 rounded-full bg-white shadow transition-transform duration-300 ${aiEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
          </button>
        </div>

        {/* API Key status */}
        <div className={`p-4 rounded-xl border mb-5 ${aiConfigured ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            <div className={`w-2.5 h-2.5 rounded-full ${aiConfigured ? 'bg-green-500' : 'bg-amber-500'}`} />
            <p className={`text-sm font-bold ${aiConfigured ? 'text-green-700' : 'text-amber-700'}`}>
              {aiConfigured ? 'API Key Configured ✓' : 'No API Key Found'}
            </p>
          </div>
          {aiStatus && (
            <p className="text-xs text-gray-500">
              Provider: <strong>{aiStatus.provider || 'none'}</strong> · Model: <strong>{aiStatus.model || 'not set'}</strong>
            </p>
          )}
          {!aiConfigured && (
            <p className="text-xs text-amber-700 mt-2">
              Add <code className="bg-amber-100 px-1 rounded font-mono">AI_API_KEY</code> to your server <code className="bg-amber-100 px-1 rounded font-mono">.env</code> file to enable AI.
            </p>
          )}
        </div>

        {/* How to add API key */}
        {!aiConfigured && (
          <div className="rounded-xl border border-gray-200 bg-gray-50 p-4 mb-5 space-y-2">
            <p className="text-xs font-bold text-gray-700">How to add your API key:</p>
            <ol className="text-xs text-gray-600 space-y-1.5 list-decimal list-inside">
              <li>Open <code className="bg-gray-200 px-1 rounded font-mono">server/.env</code></li>
              <li>Set <code className="bg-gray-200 px-1 rounded font-mono">AI_API_KEY=your_key_here</code></li>
              <li>Restart the server — AI features activate immediately</li>
            </ol>
            <a href="https://console.anthropic.com" target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs text-primary-700 font-semibold hover:underline mt-1">
              Get free Anthropic API key <ExternalLink size={10}/>
            </a>
          </div>
        )}

        {/* Test connection */}
        <div className="flex items-center gap-3">
          <button onClick={testAI} disabled={testing} className="btn-secondary text-sm">
            {testing ? <><Loader2 size={14} className="animate-spin"/>Testing...</> : <><Zap size={14}/>Test AI Connection</>}
          </button>
          {aiEffective && <span className="text-xs text-green-600 font-semibold flex items-center gap-1"><Check size={12}/>AI is fully active</span>}
        </div>

        {/* Feature status table */}
        <div className="mt-5 rounded-xl border border-gray-200 overflow-hidden">
          <div className="bg-gray-50 px-4 py-2.5 border-b border-gray-200">
            <p className="text-xs font-bold text-gray-600 uppercase tracking-wide">Feature Status</p>
          </div>
          {[
            { feature: 'BCI Score (Habits)',        status: 'always',  note: 'Always active — no AI needed'   },
            { feature: 'Goal Milestones (Template)', status: 'always',  note: 'Template-based when AI is off'  },
            { feature: 'Task Auto-Sort',             status: 'always',  note: 'Priority + date logic always works' },
            { feature: 'Journal Basic Analysis',     status: 'always',  note: 'Sentiment keywords, word count' },
            { feature: 'AI Behavior Insights',       status: 'ai',      note: 'Needs AI enabled + API key'     },
            { feature: 'AI Goal Decomposition',      status: 'ai',      note: 'Personalized milestones via AI' },
            { feature: 'AI Journal Reflection',      status: 'ai',      note: 'Deep psychological analysis'    },
            { feature: 'AI Task Prioritization',     status: 'ai',      note: 'Smart ordering via AI'          },
          ].map(row => (
            <div key={row.feature} className="flex items-center justify-between px-4 py-2.5 border-b border-gray-100 last:border-0">
              <span className="text-xs font-medium text-gray-700">{row.feature}</span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-gray-400 hidden sm:block">{row.note}</span>
                <span className={`badge text-[10px] ${row.status === 'always'
                  ? (aiEnabled && aiConfigured ? 'bg-green-100 text-green-700' : 'bg-green-100 text-green-700')
                  : (aiEffective ? 'bg-violet-100 text-violet-700' : 'bg-gray-100 text-gray-400')
                }`}>
                  {row.status === 'always' ? '✓ Active' : aiEffective ? '⚡ Active' : '○ Needs AI'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Account info */}
      <div className="card bg-gray-50 border-gray-100">
        <p className="section-title">Account Info</p>
        <div className="space-y-2 text-xs text-gray-500">
          <p>Member since: <strong className="text-gray-700">{new Date(user?.createdAt).toLocaleDateString('en-IN',{year:'numeric',month:'long',day:'numeric'})}</strong></p>
          <p>User ID: <code className="bg-gray-200 px-1 rounded text-[10px]">{user?._id}</code></p>
        </div>
      </div>
    </div>
  );
}
