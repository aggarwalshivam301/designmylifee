import { useEffect, useState } from 'react';
import { Plus, Flame, Trash2, Check, Zap, BarChart3, RefreshCw, X, ChevronDown } from 'lucide-react';
import { useAI } from '../context/AIContext';
import { habitsAPI, goalsAPI, aiAPI } from '../api/apiClient';
import BCIDisplay from '../components/BCIDisplay';

const FREQ = ['daily','weekly'];

export default function Habits() {
  const { aiEnabled, aiEffective } = useAI();
  const [habits, setHabits]   = useState([]);
  const [goals,  setGoals]    = useState([]);
  const [bci,    setBci]      = useState(null);
  const [bciLoading, setBciLoading] = useState(false);
  const [analyzing,  setAnalyzing]  = useState(false);
  const [useAIMode,  setUseAIMode]  = useState(true);
  const [showAIDropdown, setShowAIDropdown] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name:'', description:'', frequency:'daily', goalId:'' });
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []); // eslint-disable-line

  const load = async () => {
    setLoading(true);
    try {
      const [h, g] = await Promise.all([habitsAPI.getAll(), goalsAPI.getAll()]);
      setHabits(h.data); setGoals(g.data);
    } finally { setLoading(false); }
    quickBCI();
  };

  const quickBCI = async () => {
    setBciLoading(true);
    try { const { data } = await aiAPI.quickBCI({}); setBci(data); } catch {}
    finally { setBciLoading(false); }
  };

  const analyze = async () => {
    setAnalyzing(true);
    try {
      const { data } = await aiAPI.analyzeBehavior({ useAI: useAIMode && aiEffective });
      setBci(data);
    } catch {} finally { setAnalyzing(false); }
  };

  const create = async e => {
    e.preventDefault();
    try {
      const { data } = await habitsAPI.create(form);
      setHabits(p => [data, ...p]);
      setForm({ name:'', description:'', frequency:'daily', goalId:'' });
      setShowForm(false);
      quickBCI();
    } catch {}
  };

  const checkIn = async (id) => {
    try {
      const { data } = await habitsAPI.checkIn(id);
      setHabits(p => p.map(h => h._id === id ? data : h));
      quickBCI();
    } catch {}
  };

  const del = async (id) => {
    if (!confirm('Delete this habit?')) return;
    try { await habitsAPI.delete(id); setHabits(p => p.filter(h => h._id !== id)); quickBCI(); } catch {}
  };

  const isToday = (h) => {
    const today = new Date(); today.setHours(0,0,0,0);
    return h.completionHistory?.some(c => { const d = new Date(c.date); d.setHours(0,0,0,0); return d.getTime() === today.getTime() && c.completed; });
  };

  const streakColor = s => s >= 21 ? '#16a34a' : s >= 7 ? '#2563eb' : s >= 3 ? '#ca8a04' : '#9ca3af';

  return (
    <div className="p-8 max-w-7xl">

      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Habit Tracker</h1>
          <p className="text-gray-500 text-sm mt-1">Build consistency one day at a time</p>
        </div>
        <div className="flex items-center gap-2">
          {/* Analyze button with dropdown */}
          <div className="relative">
            <div className="flex gap-1">
              <button onClick={analyze} disabled={analyzing}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white transition-all ${aiEffective && useAIMode ? 'bg-gradient-to-r from-primary-700 to-blue-600 shadow-lg shadow-primary-200' : 'bg-gray-600'} disabled:opacity-60`}>
                {analyzing ? <RefreshCw size={14} className="animate-spin" /> : <BarChart3 size={14} />}
                {aiEffective && useAIMode ? '⚡ Analyze with AI' : 'Calculate BCI'}
              </button>
              <button onClick={() => setShowAIDropdown(v => !v)}
                className="px-2.5 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl text-sm transition-all"><ChevronDown size={14} /></button>
            </div>
            {showAIDropdown && (
              <div className="absolute right-0 top-full mt-2 w-72 card shadow-xl z-50 border border-gray-200">
                <p className="text-xs font-bold text-gray-700 mb-3">Analysis Mode</p>
                {[
                  { val:true,  title:'AI-Enhanced',     badge:'Recommended', desc:'Personalized insights + BCI score', time:'~3-5s' },
                  { val:false, title:'BCI Math Only',   badge:null,          desc:'Instant behavioral score, no AI needed', time:'Instant' },
                ].map(opt => (
                  <label key={String(opt.val)} className={`flex gap-3 p-3 rounded-xl cursor-pointer mb-2 border transition-colors ${useAIMode===opt.val ? 'bg-primary-50 border-primary-200' : 'bg-gray-50 border-gray-100'}`}>
                    <input type="radio" className="mt-0.5" checked={useAIMode===opt.val} onChange={() => { setUseAIMode(opt.val); setShowAIDropdown(false); }} />
                    <div>
                      <p className="text-xs font-bold text-gray-800 flex items-center gap-2">{opt.title}
                        {opt.badge && <span className="badge bg-primary-100 text-primary-700">{opt.badge}</span>}
                      </p>
                      <p className="text-[10px] text-gray-500 mt-0.5">{opt.desc} · {opt.time}</p>
                    </div>
                  </label>
                ))}
                {!aiEffective && (
                  <p className="text-[10px] text-amber-600 mt-2 p-2 bg-amber-50 rounded-lg">
                    {!aiEnabled ? 'Enable AI in sidebar to use AI analysis.' : 'No API key configured. Add one in Settings.'}
                  </p>
                )}
              </div>
            )}
          </div>
          <button onClick={() => setShowForm(v => !v)} className="btn-primary">
            <Plus size={16} /> New Habit
          </button>
        </div>
      </div>

      {/* Create Form */}
      {showForm && (
        <div className="card mb-6 border-primary-100 bg-primary-50/30">
          <div className="flex items-center justify-between mb-4">
            <p className="font-bold text-gray-800">New Habit</p>
            <button onClick={() => setShowForm(false)}><X size={16} className="text-gray-400" /></button>
          </div>
          <form onSubmit={create} className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="label">Habit Name *</label>
              <input className="input" placeholder="e.g. Morning Run" value={form.name} onChange={e => setForm(p=>({...p,name:e.target.value}))} required />
            </div>
            <div className="col-span-2">
              <label className="label">Description</label>
              <input className="input" placeholder="Optional details" value={form.description} onChange={e => setForm(p=>({...p,description:e.target.value}))} />
            </div>
            <div>
              <label className="label">Frequency</label>
              <select className="input" value={form.frequency} onChange={e => setForm(p=>({...p,frequency:e.target.value}))}>
                {FREQ.map(f => <option key={f} value={f}>{f.charAt(0).toUpperCase()+f.slice(1)}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Link to Goal</label>
              <select className="input" value={form.goalId} onChange={e => setForm(p=>({...p,goalId:e.target.value}))}>
                <option value="">— None —</option>
                {goals.map(g => <option key={g._id} value={g._id}>{g.title}</option>)}
              </select>
            </div>
            <div className="col-span-2 flex gap-2">
              <button type="submit" className="btn-primary">Create Habit</button>
              <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-3 gap-6">
        {/* Habits grid */}
        <div className="col-span-2 space-y-0">
          {loading ? (
            <div className="grid grid-cols-2 gap-4">
              {[1,2,3,4].map(i => <div key={i} className="card animate-pulse h-44" />)}
            </div>
          ) : habits.length === 0 ? (
            <div className="card text-center py-16">
              <p className="text-4xl mb-3">🌱</p>
              <p className="text-gray-500 font-medium">No habits yet</p>
              <p className="text-gray-400 text-xs mt-1">Create your first habit to start tracking</p>
              <button onClick={() => setShowForm(true)} className="btn-primary mx-auto mt-4"><Plus size={14}/>Add Habit</button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {habits.map(h => {
                const done = isToday(h);
                return (
                  <div key={h._id} className="card hover:shadow-md transition-all relative overflow-hidden">
                    <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary-600 to-blue-500" />
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-bold text-gray-800 text-sm">{h.name}</p>
                        <span className="badge bg-blue-50 text-blue-600 mt-1">{h.frequency}</span>
                      </div>
                      <button onClick={() => del(h._id)} className="text-gray-300 hover:text-red-400 transition-colors"><Trash2 size={14}/></button>
                    </div>
                    {h.description && <p className="text-xs text-gray-400 mb-3 line-clamp-1">{h.description}</p>}
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      <div className="bg-orange-50 rounded-xl p-2.5 text-center">
                        <p className="text-lg font-black" style={{ color: streakColor(h.currentStreak) }}>{h.currentStreak}<span className="text-base">🔥</span></p>
                        <p className="text-[10px] text-gray-400">Current</p>
                      </div>
                      <div className="bg-green-50 rounded-xl p-2.5 text-center">
                        <p className="text-lg font-black text-green-600">{h.longestStreak}<span className="text-base">⭐</span></p>
                        <p className="text-[10px] text-gray-400">Best</p>
                      </div>
                    </div>
                    <button onClick={() => !done && checkIn(h._id)}
                      className={`w-full py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                        done
                          ? 'bg-green-50 text-green-700 border border-green-200 cursor-default'
                          : 'bg-gradient-to-r from-primary-700 to-blue-600 text-white shadow-sm hover:shadow-md hover:-translate-y-0.5'
                      }`}>
                      <Check size={14} />{done ? 'Done Today ✓' : 'Check In'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* BCI Panel — always visible */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <p className="section-title">BCI Analysis</p>
            <button onClick={quickBCI} className="text-xs text-primary-600 hover:underline"><RefreshCw size={11} className="inline mr-1"/>Refresh</button>
          </div>
          <BCIDisplay data={bci} loading={bciLoading} />
          {!aiEnabled && (
            <div className="mt-4 p-3 rounded-xl bg-amber-50 border border-amber-100 text-xs text-amber-700">
              <p className="font-semibold mb-0.5">🤖 AI Insights</p>
              Enable AI in the sidebar to get personalized behavior analysis.
            </div>
          )}
          {aiEnabled && !aiEffective && (
            <div className="mt-4 p-3 rounded-xl bg-amber-50 border border-amber-100 text-xs text-amber-700">
              <p className="font-semibold mb-0.5">⚠️ No API Key</p>
              Add your AI API key in Settings to enable AI insights.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
