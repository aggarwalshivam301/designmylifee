import { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Volume2, VolumeX, Settings2, X } from 'lucide-react';

const PRESETS = { work:25, shortBreak:5, longBreak:15 };
const SESSION_LOG_KEY = 'dml_focus_sessions';

function useAudio() {
  const ctx = useRef(null);
  const beep = useCallback((freq=440, dur=0.3) => {
    try {
      if (!ctx.current) ctx.current = new (window.AudioContext||window.webkitAudioContext)();
      const osc = ctx.current.createOscillator();
      const gain= ctx.current.createGain();
      osc.connect(gain); gain.connect(ctx.current.destination);
      osc.frequency.value = freq; osc.type = 'sine';
      gain.gain.setValueAtTime(0.4, ctx.current.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.current.currentTime+dur);
      osc.start(); osc.stop(ctx.current.currentTime+dur);
    } catch {}
  }, []);
  return { beep };
}

export default function Focus() {
  const [mode,     setMode]     = useState('work'); // work | shortBreak | longBreak
  const [seconds,  setSeconds]  = useState(PRESETS.work * 60);
  const [running,  setRunning]  = useState(false);
  const [sessions, setSessions] = useState(() => { try { return JSON.parse(localStorage.getItem(SESSION_LOG_KEY)||'[]'); } catch { return []; } });
  const [workCount,setWorkCount]= useState(0);
  const [muted,    setMuted]    = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [custom, setCustom]    = useState({ work:25, short:5, long:15 });
  const intervalRef = useRef(null);
  const { beep } = useAudio();

  const DURATIONS = { work: custom.work*60, shortBreak: custom.short*60, longBreak: custom.long*60 };

  const reset = useCallback(() => {
    clearInterval(intervalRef.current); setRunning(false); setSeconds(DURATIONS[mode]);
  }, [mode, DURATIONS]);

  useEffect(() => { setSeconds(DURATIONS[mode]); setRunning(false); clearInterval(intervalRef.current); }, [mode]); // eslint-disable-line

  useEffect(() => {
    if (!running) { clearInterval(intervalRef.current); return; }
    intervalRef.current = setInterval(() => {
      setSeconds(s => {
        if (s <= 1) {
          clearInterval(intervalRef.current); setRunning(false);
          if (!muted) { beep(880,0.2); setTimeout(()=>beep(660,0.3),300); }
          if (mode === 'work') {
            const newCount = workCount + 1;
            setWorkCount(newCount);
            const log = { type:'work', duration:custom.work, at: new Date().toISOString() };
            const next = [...sessions, log];
            setSessions(next); localStorage.setItem(SESSION_LOG_KEY, JSON.stringify(next));
            setMode(newCount % 4 === 0 ? 'longBreak' : 'shortBreak');
          } else setMode('work');
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(intervalRef.current);
  }, [running, mode, muted, workCount, sessions, beep, custom.work]); // eslint-disable-line

  const mm = String(Math.floor(seconds/60)).padStart(2,'0');
  const ss = String(seconds%60).padStart(2,'0');
  const progress = 1 - seconds / DURATIONS[mode];

  const modeLabel = { work:'Focus Time', shortBreak:'Short Break', longBreak:'Long Break' };
  const modeColor = { work:'#7c3aed', shortBreak:'#16a34a', longBreak:'#2563eb' };
  const bgColor   = { work:'from-violet-50 to-purple-50', shortBreak:'from-green-50 to-emerald-50', longBreak:'from-blue-50 to-indigo-50' };
  const todaySessions = sessions.filter(s => new Date(s.at).toDateString() === new Date().toDateString());
  const totalFocusMin = todaySessions.reduce((a,s)=>a+(s.duration||0),0);

  const r=110; const circ=2*Math.PI*r;

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Focus</h1>
          <p className="text-gray-500 text-sm mt-1">Pomodoro timer · Stay deep in the work</p>
        </div>
        <button onClick={()=>setShowSettings(v=>!v)} className="btn-secondary"><Settings2 size={16}/>Settings</button>
      </div>

      {/* Settings modal */}
      {showSettings && (
        <div className="card mb-6 border-gray-200">
          <div className="flex justify-between items-center mb-4"><p className="font-bold text-gray-800">Timer Settings</p><button onClick={()=>setShowSettings(false)}><X size={16} className="text-gray-400"/></button></div>
          <div className="grid grid-cols-3 gap-4">
            {[['Focus (min)','work'],['Short Break','short'],['Long Break','long']].map(([label,key])=>(
              <div key={key}>
                <label className="label">{label}</label>
                <input className="input" type="number" min="1" max="90" value={custom[key]} onChange={e=>setCustom(p=>({...p,[key]:+e.target.value}))} />
              </div>
            ))}
          </div>
          <button onClick={()=>{setShowSettings(false);setSeconds(DURATIONS[mode]);setRunning(false);}} className="btn-primary mt-4">Apply</button>
        </div>
      )}

      {/* Mode selector */}
      <div className="flex gap-2 mb-8 justify-center">
        {Object.entries(modeLabel).map(([m,label])=>(
          <button key={m} onClick={()=>setMode(m)}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${mode===m?'text-white shadow-md':'bg-white text-gray-500 border border-gray-200 hover:bg-gray-50'}`}
            style={mode===m?{background:modeColor[m]}:{}}>
            {label}
          </button>
        ))}
      </div>

      {/* Timer circle */}
      <div className={`card bg-gradient-to-br ${bgColor[mode]} border-0 shadow-xl mb-8 flex flex-col items-center py-12`}>
        <div className="relative mb-6">
          <svg width="260" height="260">
            <circle cx="130" cy="130" r={r} fill="none" stroke="#e5e7eb" strokeWidth="10"/>
            <circle cx="130" cy="130" r={r} fill="none" stroke={modeColor[mode]} strokeWidth="10"
              strokeDasharray={circ} strokeDashoffset={circ*(1-progress)}
              strokeLinecap="round" transform="rotate(-90 130 130)"
              style={{transition:'stroke-dashoffset 1s linear'}}/>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <p className="text-5xl font-black tabular-nums" style={{color:modeColor[mode]}}>{mm}:{ss}</p>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">{modeLabel[mode]}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={reset} className="btn-secondary p-2.5 rounded-xl"><RotateCcw size={18}/></button>
          <button onClick={()=>setRunning(v=>!v)}
            className="flex items-center gap-2 px-8 py-3 rounded-xl text-white font-bold text-lg shadow-lg transition-all hover:opacity-90 hover:scale-105 active:scale-95"
            style={{background:modeColor[mode]}}>
            {running?<><Pause size={20}/>Pause</>:<><Play size={20}/>Start</>}
          </button>
          <button onClick={()=>setMode(mode==='work'?'shortBreak':'work')} className="btn-secondary p-2.5 rounded-xl"><SkipForward size={18}/></button>
        </div>
        <button onClick={()=>setMuted(v=>!v)} className="mt-4 flex items-center gap-1.5 text-xs text-gray-400 hover:text-gray-600">
          {muted?<VolumeX size={14}/>:<Volume2 size={14}/>} {muted?'Sound off':'Sound on'}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="card text-center py-4">
          <p className="text-2xl font-black text-primary-700">{workCount}</p>
          <p className="text-xs text-gray-400">Sessions today</p>
        </div>
        <div className="card text-center py-4">
          <p className="text-2xl font-black text-blue-700">{totalFocusMin}</p>
          <p className="text-xs text-gray-400">Focus minutes</p>
        </div>
        <div className="card text-center py-4">
          <p className="text-2xl font-black text-green-700">{Math.floor(workCount/4)}</p>
          <p className="text-xs text-gray-400">Pomodoros done</p>
        </div>
      </div>

      {/* Session log */}
      {todaySessions.length > 0 && (
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <p className="section-title">Today's Sessions</p>
            <button onClick={()=>{setSessions([]);localStorage.removeItem(SESSION_LOG_KEY);setWorkCount(0);}} className="text-[10px] text-red-400 hover:underline">Clear</button>
          </div>
          <div className="space-y-1.5 max-h-40 overflow-y-auto">
            {[...todaySessions].reverse().map((s,i)=>(
              <div key={i} className="flex items-center justify-between text-xs text-gray-600 py-1 border-b border-gray-50 last:border-0">
                <span className="font-medium">🍅 {s.type==='work'?'Focus':'Break'} — {s.duration} min</span>
                <span className="text-gray-400">{new Date(s.at).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
