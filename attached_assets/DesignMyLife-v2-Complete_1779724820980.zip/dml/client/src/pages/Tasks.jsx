import { useEffect, useState } from 'react';
import { Plus, Trash2, Check, Sparkles, X, Loader2, Calendar } from 'lucide-react';
import { useAI } from '../context/AIContext';
import { tasksAPI, goalsAPI, aiAPI } from '../api/apiClient';

const PRIORITY = ['low','medium','high','urgent'];
const STATUS   = ['todo','in-progress','completed'];
const PCOL = { urgent:'bg-red-100 text-red-700 border-red-200', high:'bg-orange-100 text-orange-700 border-orange-200', medium:'bg-yellow-100 text-yellow-700 border-yellow-200', low:'bg-gray-100 text-gray-600 border-gray-200' };
const PCIRCLE = { urgent:'bg-red-500', high:'bg-orange-500', medium:'bg-yellow-400', low:'bg-gray-300' };

export default function Tasks() {
  const { aiEnabled, aiEffective } = useAI();
  const [tasks,  setTasks]   = useState([]);
  const [goals,  setGoals]   = useState([]);
  const [filter, setFilter]  = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [optimizing, setOptimizing] = useState(false);
  const [aiResult, setAiResult]     = useState(null);
  const [form, setForm] = useState({ title:'',description:'',priority:'medium',dueDate:'',goalId:'',estimatedMinutes:30 });

  useEffect(() => { load(); }, []); // eslint-disable-line
  const load = async () => {
    try {
      const [t, g] = await Promise.all([tasksAPI.getAll(), goalsAPI.getAll()]);
      setTasks(t.data); setGoals(g.data);
    } catch {}
  };

  const create = async e => {
    e.preventDefault();
    try {
      const { data } = await tasksAPI.create(form);
      setTasks(p => [data,...p]);
      setForm({ title:'',description:'',priority:'medium',dueDate:'',goalId:'',estimatedMinutes:30 });
      setShowForm(false);
    } catch {}
  };

  const updateStatus = async (id, status) => {
    try { const { data } = await tasksAPI.update(id, { status }); setTasks(p => p.map(t => t._id===id?data:t)); } catch {}
  };

  const del = async id => {
    if (!confirm('Delete this task?')) return;
    try { await tasksAPI.delete(id); setTasks(p => p.filter(t => t._id!==id)); } catch {}
  };

  const optimize = async () => {
    setOptimizing(true); setAiResult(null);
    try { const { data } = await aiAPI.optimizeTasks({ useAI: aiEffective }); setAiResult(data); } catch {}
    finally { setOptimizing(false); }
  };

  const filtered = tasks.filter(t => filter === 'all' ? true : filter === 'today' ? t.status !== 'completed' : t.status === filter);

  const orderedTasks = aiResult?.orderedTasks
    ? [...filtered].sort((a,b) => {
        const ra = aiResult.orderedTasks.find(o=>o.id?.toString()===a._id?.toString())?.rank ?? 999;
        const rb = aiResult.orderedTasks.find(o=>o.id?.toString()===b._id?.toString())?.rank ?? 999;
        return ra - rb;
      })
    : filtered;

  const isOverdue = t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'completed';

  return (
    <div className="p-8 max-w-4xl">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Tasks</h1>
          <p className="text-gray-500 text-sm mt-1">{tasks.filter(t=>t.status!=='completed').length} pending · {tasks.filter(t=>t.status==='completed').length} done</p>
        </div>
        <div className="flex gap-2">
          <button onClick={optimize} disabled={optimizing}
            className={`flex items-center gap-2 text-sm font-bold px-4 py-2 rounded-xl transition-all ${aiEffective ? 'bg-violet-100 text-violet-700 hover:bg-violet-200' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'} disabled:opacity-60`}>
            {optimizing ? <Loader2 size={14} className="animate-spin"/> : <Sparkles size={14}/>}
            {aiEffective ? 'AI Prioritize' : 'Auto Sort'}
          </button>
          <button onClick={() => setShowForm(v=>!v)} className="btn-primary"><Plus size={16}/>New Task</button>
        </div>
      </div>

      {/* AI result banner */}
      {aiResult && (
        <div className="card mb-4 bg-violet-50 border-violet-100">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold text-violet-700 mb-1">{aiResult.mode==='ai'?'⚡ AI':'📊 Auto'} Prioritization Applied</p>
              <p className="text-xs text-violet-600">{aiResult.advice}</p>
              {aiResult.totalEstimatedHours && <p className="text-[10px] text-violet-500 mt-1">Total estimated: {aiResult.totalEstimatedHours}h</p>}
            </div>
            <button onClick={()=>setAiResult(null)}><X size={14} className="text-violet-400"/></button>
          </div>
        </div>
      )}

      {/* Create Form */}
      {showForm && (
        <div className="card mb-6 border-primary-100 bg-primary-50/30">
          <div className="flex items-center justify-between mb-4">
            <p className="font-bold text-gray-800">New Task</p>
            <button onClick={()=>setShowForm(false)}><X size={16} className="text-gray-400"/></button>
          </div>
          <form onSubmit={create} className="grid grid-cols-2 gap-4">
            <div className="col-span-2"><label className="label">Task Title *</label><input className="input" placeholder="What needs to be done?" value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))} required /></div>
            <div className="col-span-2"><label className="label">Description</label><input className="input" placeholder="Optional details" value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))}/></div>
            <div><label className="label">Priority</label>
              <select className="input" value={form.priority} onChange={e=>setForm(p=>({...p,priority:e.target.value}))}>
                {PRIORITY.map(p=><option key={p} value={p}>{p.charAt(0).toUpperCase()+p.slice(1)}</option>)}
              </select>
            </div>
            <div><label className="label">Due Date</label><input className="input" type="date" value={form.dueDate} onChange={e=>setForm(p=>({...p,dueDate:e.target.value}))}/></div>
            <div><label className="label">Est. Minutes</label><input className="input" type="number" min="5" value={form.estimatedMinutes} onChange={e=>setForm(p=>({...p,estimatedMinutes:+e.target.value}))}/></div>
            <div><label className="label">Link to Goal</label>
              <select className="input" value={form.goalId} onChange={e=>setForm(p=>({...p,goalId:e.target.value}))}>
                <option value="">— None —</option>
                {goals.map(g=><option key={g._id} value={g._id}>{g.title}</option>)}
              </select>
            </div>
            <div className="col-span-2 flex gap-2"><button type="submit" className="btn-primary">Create Task</button><button type="button" className="btn-secondary" onClick={()=>setShowForm(false)}>Cancel</button></div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-2 mb-4 flex-wrap">
        {['all','todo','in-progress','completed','today'].map(f => (
          <button key={f} onClick={()=>setFilter(f)}
            className={`text-xs px-3 py-1.5 rounded-full font-semibold transition-all ${filter===f?'bg-primary-700 text-white shadow':'bg-white text-gray-500 border border-gray-200 hover:bg-gray-50'}`}>
            {f==='all'?'All':f.split('-').map(w=>w[0].toUpperCase()+w.slice(1)).join('-')}
            <span className="ml-1 opacity-70">({f==='all'?tasks.length:f==='today'?tasks.filter(t=>t.status!=='completed').length:tasks.filter(t=>t.status===f).length})</span>
          </button>
        ))}
      </div>

      {/* Tasks list */}
      {orderedTasks.length === 0 ? (
        <div className="card text-center py-12"><p className="text-4xl mb-3">✅</p><p className="text-gray-500 font-medium">{filter==='completed'?'No completed tasks yet':'All clear!'}</p></div>
      ) : (
        <div className="space-y-2">
          {orderedTasks.map((t,i) => {
            const rank = aiResult?.orderedTasks?.find(o=>o.id?.toString()===t._id?.toString());
            return (
              <div key={t._id} className={`card py-3 px-4 flex items-center gap-3 hover:shadow-sm transition-all ${isOverdue(t)?'border-red-200 bg-red-50/30':''} ${t.status==='completed'?'opacity-60':''}`}>
                {aiResult && <span className="text-xs font-black text-gray-300 w-4">#{rank?.rank||i+1}</span>}
                <button onClick={()=>updateStatus(t._id,t.status==='completed'?'todo':'completed')}
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${t.status==='completed'?'bg-green-500 border-green-500':'border-gray-300 hover:border-primary-500'}`}>
                  {t.status==='completed'&&<Check size={10} className="text-white"/>}
                </button>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium truncate ${t.status==='completed'?'line-through text-gray-400':'text-gray-800'}`}>{t.title}</p>
                  <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                    <span className={`badge text-[10px] border ${PCOL[t.priority]}`}>{t.priority}</span>
                    {t.dueDate&&<span className={`text-[10px] flex items-center gap-0.5 ${isOverdue(t)?'text-red-500 font-semibold':'text-gray-400'}`}><Calendar size={9}/>{new Date(t.dueDate).toLocaleDateString('en-IN',{month:'short',day:'numeric'})}</span>}
                    {t.goalId&&<span className="text-[10px] text-primary-600 font-medium">🎯 {typeof t.goalId==='object'?t.goalId.title:'Linked'}</span>}
                    {rank?.reason&&<span className="text-[10px] text-violet-500">{rank.reason}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <select className="text-[10px] border border-gray-200 rounded-lg px-1.5 py-1 bg-gray-50 text-gray-600"
                    value={t.status} onChange={e=>updateStatus(t._id,e.target.value)}>
                    {STATUS.map(s=><option key={s} value={s}>{s}</option>)}
                  </select>
                  <button onClick={()=>del(t._id)} className="text-gray-300 hover:text-red-400 transition-colors"><Trash2 size={13}/></button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
