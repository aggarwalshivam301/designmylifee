import { useEffect, useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { habitsAPI, goalsAPI, tasksAPI, aiAPI } from '../api/apiClient';

const COLORS = ['#7c3aed','#2563eb','#16a34a','#ca8a04','#ec4899','#ea580c','#9ca3af'];

export default function Analytics() {
  const [habits,  setHabits]  = useState([]);
  const [goals,   setGoals]   = useState([]);
  const [tasks,   setTasks]   = useState([]);
  const [bci,     setBci]     = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, []); // eslint-disable-line

  const load = async () => {
    try {
      const [h,g,t,b] = await Promise.all([habitsAPI.getAll(), goalsAPI.getAll(), tasksAPI.getAll(), aiAPI.quickBCI({})]);
      setHabits(h.data); setGoals(g.data); setTasks(t.data); setBci(b.data);
    } catch {} finally { setLoading(false); }
  };

  // Last 7 days completion data
  const last7 = Array.from({length:7},(_,i)=>{
    const d = new Date(); d.setDate(d.getDate()-6+i); d.setHours(0,0,0,0);
    const label = d.toLocaleDateString('en-IN',{weekday:'short'});
    const done  = habits.reduce((sum,h)=>{
      const completed = h.completionHistory?.some(c=>{ const cd=new Date(c.date); cd.setHours(0,0,0,0); return cd.getTime()===d.getTime()&&c.completed; });
      return sum + (completed?1:0);
    },0);
    return { day:label, completed:done, total:habits.length };
  });

  // Habit completion rates
  const habitRates = habits.map(h=>{
    const history  = h.completionHistory || [];
    const now      = Date.now();
    const last30   = history.filter(c=>(now-new Date(c.date))/86400000<=30&&c.completed).length;
    const freq     = h.frequency==='daily'?30:12;
    return { name:h.name.length>16?h.name.slice(0,15)+'…':h.name, rate:Math.round((last30/freq)*100), streak:h.currentStreak };
  });

  // Task pie
  const taskPie = [
    { name:'Todo',        value:tasks.filter(t=>t.status==='todo').length        },
    { name:'In Progress', value:tasks.filter(t=>t.status==='in-progress').length },
    { name:'Completed',   value:tasks.filter(t=>t.status==='completed').length   },
  ].filter(d=>d.value>0);

  // Goal by category
  const goalsByCat = goals.reduce((acc,g)=>{ acc[g.category]=(acc[g.category]||0)+1; return acc; },{});
  const goalCatData = Object.entries(goalsByCat).map(([name,value])=>({name,value}));

  const bciColor = bci?.score>=80?'#16a34a':bci?.score>=65?'#2563eb':bci?.score>=50?'#ca8a04':'#dc2626';

  if (loading) return <div className="p-8 flex items-center justify-center h-64"><div className="text-gray-400 text-sm">Loading analytics...</div></div>;

  return (
    <div className="p-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-black text-gray-900">Analytics</h1>
        <p className="text-gray-500 text-sm mt-1">Your behavioral patterns at a glance</p>
      </div>

      {/* BCI + Streak Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label:'BCI Score',    value:bci?.score??0, unit:'/100', color:bciColor },
          { label:'Grade',        value:bci?.grade??'N/A', unit:'', color:bciColor },
          { label:'Success Prob', value:`${bci?.prediction?.successProbability??0}%`, unit:'', color:'#7c3aed' },
          { label:'Active Habits',value:habits.length, unit:'', color:'#2563eb' },
        ].map(s=>(
          <div key={s.label} className="card text-center">
            <p className="text-3xl font-black" style={{color:s.color}}>{s.value}<span className="text-sm text-gray-400">{s.unit}</span></p>
            <p className="text-xs text-gray-400 mt-1 font-medium">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        {/* 7-day habit completions */}
        <div className="card">
          <p className="section-title mb-4">Daily Habit Completions — Last 7 Days</p>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={last7} barSize={30}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
              <XAxis dataKey="day" tick={{fontSize:11}} axisLine={false} tickLine={false}/>
              <YAxis tick={{fontSize:11}} axisLine={false} tickLine={false}/>
              <Tooltip contentStyle={{borderRadius:10,border:'1px solid #e9e5ff',fontSize:12}}/>
              <Bar dataKey="completed" fill="#7c3aed" radius={[6,6,0,0]} name="Completed"/>
              <Bar dataKey="total"     fill="#e0e7ff" radius={[6,6,0,0]} name="Total" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Habit completion rates */}
        <div className="card">
          <p className="section-title mb-4">30-Day Completion Rate by Habit</p>
          {habitRates.length===0?<p className="text-xs text-gray-400 text-center py-8">No habit data yet</p>:(
            <div className="space-y-3">
              {habitRates.map((h,i)=>(
                <div key={i}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-medium text-gray-700 truncate">{h.name}</span>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-orange-500 font-bold text-[10px]">🔥{h.streak}</span>
                      <span className="font-bold text-primary-700">{h.rate}%</span>
                    </div>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{width:`${h.rate}%`,background:COLORS[i%COLORS.length]}}/>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Task status pie */}
        <div className="card">
          <p className="section-title mb-4">Task Status Breakdown</p>
          {taskPie.length===0?<p className="text-xs text-gray-400 text-center py-8">No tasks yet</p>:(
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={taskPie} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                  {taskPie.map((_,i)=><Cell key={i} fill={['#e5e7eb','#93c5fd','#7c3aed'][i]||COLORS[i]}/>)}
                </Pie>
                <Legend iconType="circle" iconSize={8} wrapperStyle={{fontSize:11}}/>
                <Tooltip contentStyle={{borderRadius:10,fontSize:11}}/>
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Goal progress */}
        <div className="card">
          <p className="section-title mb-4">Goal Progress</p>
          {goals.length===0?<p className="text-xs text-gray-400 text-center py-8">No goals yet</p>:(
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={goals.filter(g=>g.status==='active').slice(0,6).map(g=>({name:g.title.slice(0,16),progress:g.progress}))} layout="vertical" barSize={16}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                <XAxis type="number" domain={[0,100]} tick={{fontSize:10}} axisLine={false} tickLine={false}/>
                <YAxis dataKey="name" type="category" tick={{fontSize:10}} width={90} axisLine={false} tickLine={false}/>
                <Tooltip formatter={v=>`${v}%`} contentStyle={{borderRadius:10,fontSize:11}}/>
                <Bar dataKey="progress" fill="#7c3aed" radius={[0,6,6,0]} name="Progress"/>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* BCI breakdown */}
      {bci?.breakdown && (
        <div className="card">
          <p className="section-title mb-4">BCI Score Breakdown</p>
          <div className="grid grid-cols-4 gap-4">
            {[
              {label:'Streak Consistency',val:bci.breakdown.streakConsistency,wt:'40%',c:'#16a34a'},
              {label:'Completion Rate',   val:bci.breakdown.completionRate,   wt:'30%',c:'#2563eb'},
              {label:'Time Consistency',  val:bci.breakdown.timeConsistency,  wt:'20%',c:'#ca8a04'},
              {label:'Goal Alignment',    val:bci.breakdown.goalAlignment,    wt:'10%',c:'#7c3aed'},
            ].map(b=>(
              <div key={b.label} className="text-center p-4 rounded-xl bg-gray-50">
                <p className="text-2xl font-black mb-1" style={{color:b.c}}>{b.val}</p>
                <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wide">{b.label}</p>
                <p className="text-[10px] text-gray-300 mt-0.5">weight: {b.wt}</p>
                <div className="progress-bar mt-2"><div className="progress-fill" style={{width:`${b.val}%`,background:b.c}}/></div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
