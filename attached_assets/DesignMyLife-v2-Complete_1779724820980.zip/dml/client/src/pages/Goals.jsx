import { useEffect, useState } from 'react';
import { Plus, Trash2, Sparkles, ChevronDown, X, Check, Loader2 } from 'lucide-react';
import { useAI } from '../context/AIContext';
import { goalsAPI, aiAPI } from '../api/apiClient';

const CATS = ['career','health','learning','finance','relationships','project','other'];
const STATUS_COLORS = { active:'bg-green-100 text-green-700', completed:'bg-blue-100 text-blue-700', paused:'bg-gray-100 text-gray-600' };
const CAT_COLORS    = { career:'bg-purple-100 text-purple-700', health:'bg-green-100 text-green-700', learning:'bg-blue-100 text-blue-700', finance:'bg-yellow-100 text-yellow-700', relationships:'bg-pink-100 text-pink-700', project:'bg-orange-100 text-orange-700', other:'bg-gray-100 text-gray-600' };

export default function Goals() {
  const { aiEnabled, aiEffective } = useAI();
  const [goals, setGoals]     = useState([]);
  const [showForm, setShowForm]= useState(false);
  const [decomposing, setDecomposing] = useState(null);
  const [expanded,   setExpanded]     = useState(null);
  const [form, setForm] = useState({ title:'', description:'', category:'career', targetDate:'' });

  useEffect(() => { load(); }, []); // eslint-disable-line
  const load = async () => { try { const { data } = await goalsAPI.getAll(); setGoals(data); } catch {} };

  const create = async e => {
    e.preventDefault();
    try { const { data } = await goalsAPI.create(form); setGoals(p => [data,...p]); setForm({ title:'',description:'',category:'career',targetDate:'' }); setShowForm(false); } catch {}
  };

  const del = async id => {
    if (!confirm('Delete this goal?')) return;
    try { await goalsAPI.delete(id); setGoals(p => p.filter(g => g._id !== id)); } catch {}
  };

  const updateProgress = async (id, progress) => {
    try {
      const { data } = await goalsAPI.update(id, { progress });
      setGoals(p => p.map(g => g._id === id ? data : g));
    } catch {}
  };

  const updateStatus = async (id, status) => {
    try {
      const { data } = await goalsAPI.update(id, { status });
      setGoals(p => p.map(g => g._id === id ? data : g));
    } catch {}
  };

  const decompose = async (goalId) => {
    setDecomposing(goalId);
    try {
      const { data } = await aiAPI.decomposeGoal({ goalId, useAI: aiEffective });
      if (data.milestones) {
        await goalsAPI.setMilestones(goalId, data.milestones);
        const { data: updated } = await goalsAPI.getAll();
        setGoals(updated);
      }
      setExpanded(goalId);
    } catch {} finally { setDecomposing(null); }
  };

  const toggleMilestone = async (goal, msId) => {
    const milestones = goal.milestones.map(m => m._id === msId ? { ...m, done: !m.done } : m);
    const progress   = Math.round((milestones.filter(m=>m.done).length / milestones.length) * 100);
    try {
      await goalsAPI.setMilestones(goal._id, milestones);
      const { data } = await goalsAPI.update(goal._id, { progress });
      setGoals(p => p.map(g => g._id === goal._id ? data : g));
    } catch {}
  };

  const progressColor = p => p >= 75 ? '#16a34a' : p >= 40 ? '#2563eb' : '#ca8a04';

  return (
    <div className="p-8 max-w-5xl">
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Goals</h1>
          <p className="text-gray-500 text-sm mt-1">Your vision, broken into achievable milestones</p>
        </div>
        <button onClick={() => setShowForm(v => !v)} className="btn-primary"><Plus size={16}/>New Goal</button>
      </div>

      {showForm && (
        <div className="card mb-6 border-primary-100 bg-primary-50/30">
          <div className="flex items-center justify-between mb-4">
            <p className="font-bold text-gray-800">New Goal</p>
            <button onClick={() => setShowForm(false)}><X size={16} className="text-gray-400"/></button>
          </div>
          <form onSubmit={create} className="grid grid-cols-2 gap-4">
            <div className="col-span-2"><label className="label">Goal Title *</label><input className="input" placeholder="e.g. Land a Full Stack Developer role" value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))} required /></div>
            <div className="col-span-2"><label className="label">Description</label><textarea className="input resize-none" rows={2} placeholder="Why this goal matters..." value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))} /></div>
            <div><label className="label">Category</label>
              <select className="input" value={form.category} onChange={e=>setForm(p=>({...p,category:e.target.value}))}>
                {CATS.map(c=><option key={c} value={c}>{c.charAt(0).toUpperCase()+c.slice(1)}</option>)}
              </select>
            </div>
            <div><label className="label">Target Date</label><input className="input" type="date" value={form.targetDate} onChange={e=>setForm(p=>({...p,targetDate:e.target.value}))}/></div>
            <div className="col-span-2 flex gap-2"><button type="submit" className="btn-primary">Create Goal</button><button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>Cancel</button></div>
          </form>
        </div>
      )}

      {goals.length === 0 ? (
        <div className="card text-center py-16"><p className="text-4xl mb-3">🎯</p><p className="text-gray-500">No goals yet</p><button onClick={()=>setShowForm(true)} className="btn-primary mx-auto mt-4"><Plus size={14}/>Create Goal</button></div>
      ) : (
        <div className="space-y-4">
          {goals.map(g => (
            <div key={g._id} className="card">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h3 className="font-bold text-gray-900">{g.title}</h3>
                    <span className={`badge ${CAT_COLORS[g.category] || 'bg-gray-100 text-gray-600'}`}>{g.category}</span>
                    <span className={`badge ${STATUS_COLORS[g.status]}`}>{g.status}</span>
                  </div>
                  {g.description && <p className="text-xs text-gray-500">{g.description}</p>}
                </div>
                <div className="flex items-center gap-2 ml-4">
                  <select className="text-xs border border-gray-200 rounded-lg px-2 py-1 bg-gray-50 text-gray-600"
                    value={g.status} onChange={e=>updateStatus(g._id, e.target.value)}>
                    {['active','paused','completed'].map(s=><option key={s} value={s}>{s}</option>)}
                  </select>
                  <button onClick={()=>del(g._id)} className="text-gray-300 hover:text-red-400 transition-colors"><Trash2 size={14}/></button>
                </div>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-gray-500 font-medium">Progress</span>
                  <span className="font-bold" style={{color:progressColor(g.progress)}}>{g.progress}%</span>
                </div>
                <input type="range" min="0" max="100" value={g.progress} onChange={e=>updateProgress(g._id,+e.target.value)}
                  className="w-full h-2 rounded-full appearance-none cursor-pointer accent-primary-600" />
              </div>

              {/* AI Decompose / Milestones */}
              <div className="flex items-center gap-2 flex-wrap">
                <button onClick={() => decompose(g._id)} disabled={!!decomposing}
                  className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl font-semibold transition-all ${aiEffective ? 'bg-violet-100 text-violet-700 hover:bg-violet-200' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
                  {decomposing === g._id ? <Loader2 size={11} className="animate-spin"/> : <Sparkles size={11}/>}
                  {aiEffective ? 'AI Decompose' : 'Auto Milestones'}
                </button>
                {g.milestones?.length > 0 && (
                  <button onClick={()=>setExpanded(p=>p===g._id?null:g._id)} className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700">
                    {g.milestones.length} milestones <ChevronDown size={11} className={`transition-transform ${expanded===g._id?'rotate-180':''}`}/>
                  </button>
                )}
                {g.targetDate && <span className="text-[11px] text-gray-400">Due: {new Date(g.targetDate).toLocaleDateString('en-IN',{month:'short',day:'numeric',year:'numeric'})}</span>}
              </div>

              {/* Milestones list */}
              {expanded === g._id && g.milestones?.length > 0 && (
                <div className="mt-4 space-y-2 border-t border-gray-100 pt-4">
                  {g.milestones.map(m => (
                    <div key={m._id} className="flex items-center gap-3">
                      <button onClick={() => toggleMilestone(g, m._id)}
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all flex-shrink-0 ${m.done ? 'bg-green-500 border-green-500' : 'border-gray-300 hover:border-primary-400'}`}>
                        {m.done && <Check size={10} className="text-white"/>}
                      </button>
                      <span className={`text-sm ${m.done ? 'line-through text-gray-400' : 'text-gray-700'}`}>{m.title}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
