import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckSquare, Target, ListChecks, Flame, ChevronRight, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAI }   from '../context/AIContext';
import { habitsAPI, goalsAPI, tasksAPI, aiAPI } from '../api/apiClient';
import BCIDisplay from '../components/BCIDisplay';

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
};

export default function Dashboard() {
  const { user } = useAuth();
  const { aiEnabled } = useAI();
  const [habits, setHabits]   = useState([]);
  const [goals,  setGoals]    = useState([]);
  const [tasks,  setTasks]    = useState([]);
  const [bci,    setBci]      = useState(null);
  const [bciLoading, setBciLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      habitsAPI.getAll(),
      goalsAPI.getAll(),
      tasksAPI.getToday(),
    ]).then(([h, g, t]) => {
      setHabits(h.data); setGoals(g.data); setTasks(t.data);
    }).catch(console.error);
    loadBCI();
  }, []); // eslint-disable-line

  const loadBCI = async () => {
    setBciLoading(true);
    try {
      const { data } = await aiAPI.quickBCI({});
      setBci(data);
    } catch { setBci(null); }
    finally { setBciLoading(false); }
  };

  const completedToday = habits.filter(h => {
    const today = new Date(); today.setHours(0,0,0,0);
    return h.completionHistory?.some(c => { const d = new Date(c.date); d.setHours(0,0,0,0); return d.getTime() === today.getTime() && c.completed; });
  }).length;

  const activeGoals  = goals.filter(g => g.status === 'active').length;
  const pendingTasks = tasks.filter(t => t.status !== 'completed').length;

  const stats = [
    { label: 'Habits Today', value: `${completedToday}/${habits.length}`, icon: CheckSquare, color: 'text-green-600', bg: 'bg-green-50', link: '/habits' },
    { label: 'Active Goals', value: activeGoals,    icon: Target,      color: 'text-blue-600',   bg: 'bg-blue-50',   link: '/goals'  },
    { label: 'Tasks Due',    value: pendingTasks,   icon: ListChecks,  color: 'text-orange-600', bg: 'bg-orange-50', link: '/tasks'  },
    { label: 'Best Streak',  value: `${Math.max(0, ...habits.map(h => h.currentStreak || 0))}d`, icon: Flame, color: 'text-red-600', bg: 'bg-red-50', link: '/habits' },
  ];

  const handleCheckIn = async (id) => {
    try {
      const { data } = await habitsAPI.checkIn(id);
      setHabits(prev => prev.map(h => h._id === id ? data : h));
      loadBCI();
    } catch {}
  };

  const isCheckedToday = (habit) => {
    const today = new Date(); today.setHours(0,0,0,0);
    return habit.completionHistory?.some(c => { const d = new Date(c.date); d.setHours(0,0,0,0); return d.getTime() === today.getTime() && c.completed; });
  };

  return (
    <div className="p-8 max-w-7xl">

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-black text-gray-900">{greeting()}, {user?.name?.split(' ')[0]} 👋</h1>
        <p className="text-gray-500 mt-1 text-sm">{new Date().toLocaleDateString('en-IN', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {stats.map(s => (
          <Link key={s.label} to={s.link} className="card hover:shadow-md hover:-translate-y-0.5 transition-all duration-150">
            <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center mb-3`}>
              <s.icon size={20} className={s.color} />
            </div>
            <p className={`text-2xl font-black ${s.color}`}>{s.value}</p>
            <p className="text-xs text-gray-400 font-medium mt-0.5">{s.label}</p>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-6">

        {/* Today's Habits */}
        <div className="col-span-2 card">
          <div className="flex items-center justify-between mb-5">
            <div>
              <p className="section-title">Today's Habits</p>
              <p className="text-gray-500 text-xs">{completedToday} of {habits.length} done</p>
            </div>
            <Link to="/habits" className="text-xs text-primary-600 font-semibold flex items-center gap-0.5 hover:underline">
              View all <ChevronRight size={12} />
            </Link>
          </div>
          {habits.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-400 text-sm">No habits yet.</p>
              <Link to="/habits" className="text-primary-700 text-xs font-semibold mt-1 inline-block hover:underline">+ Create your first habit</Link>
            </div>
          ) : (
            <div className="space-y-2">
              {habits.slice(0, 6).map(h => {
                const done = isCheckedToday(h);
                return (
                  <div key={h._id} className={`flex items-center justify-between p-3 rounded-xl border transition-colors ${done ? 'bg-green-50 border-green-100' : 'bg-gray-50 border-gray-100 hover:bg-gray-100'}`}>
                    <div className="flex items-center gap-3">
                      <button onClick={() => !done && handleCheckIn(h._id)}
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${done ? 'bg-green-500 border-green-500 text-white' : 'border-gray-300 hover:border-primary-500'}`}>
                        {done && <span className="text-xs">✓</span>}
                      </button>
                      <span className={`text-sm font-medium ${done ? 'text-green-700 line-through' : 'text-gray-700'}`}>{h.name}</span>
                    </div>
                    <span className="text-xs text-orange-500 font-bold flex items-center gap-0.5"><Flame size={11} />{h.currentStreak}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* BCI Snapshot */}
        <div className="card">
          <p className="section-title mb-4">BCI Snapshot</p>
          <BCIDisplay data={bci} loading={bciLoading} compact={false} />
          <Link to="/habits" className="btn-primary w-full justify-center mt-4 text-sm">View Full Analysis</Link>
        </div>

        {/* Goals */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <p className="section-title">Active Goals</p>
            <Link to="/goals" className="text-xs text-primary-600 font-semibold hover:underline flex items-center gap-0.5">View all <ChevronRight size={12}/></Link>
          </div>
          {goals.filter(g => g.status === 'active').slice(0, 4).map(g => (
            <div key={g._id} className="mb-4">
              <div className="flex justify-between text-xs mb-1.5">
                <span className="font-medium text-gray-700 truncate pr-2">{g.title}</span>
                <span className="font-bold text-primary-700 flex-shrink-0">{g.progress}%</span>
              </div>
              <div className="progress-bar"><div className="progress-fill bg-primary-600" style={{ width: `${g.progress}%` }} /></div>
            </div>
          ))}
          {goals.length === 0 && <p className="text-xs text-gray-400 text-center py-4">No goals yet. <Link to="/goals" className="text-primary-700 font-semibold">Create one →</Link></p>}
        </div>

        {/* Today's Tasks */}
        <div className="card col-span-2">
          <div className="flex items-center justify-between mb-4">
            <p className="section-title">Today's Tasks</p>
            <Link to="/tasks" className="text-xs text-primary-600 font-semibold hover:underline flex items-center gap-0.5">View all <ChevronRight size={12}/></Link>
          </div>
          {tasks.length === 0 ? (
            <p className="text-xs text-gray-400 text-center py-4">No tasks today. <Link to="/tasks" className="text-primary-700 font-semibold">Add one →</Link></p>
          ) : (
            <div className="space-y-2">
              {tasks.slice(0, 5).map(t => (
                <div key={t._id} className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 bg-gray-50">
                  <span className={`w-2 h-2 rounded-full flex-shrink-0 ${t.priority === 'urgent' ? 'bg-red-500' : t.priority === 'high' ? 'bg-orange-500' : t.priority === 'medium' ? 'bg-yellow-500' : 'bg-gray-300'}`} />
                  <span className="text-sm font-medium text-gray-700 flex-1 truncate">{t.title}</span>
                  <span className={`badge text-xs ${t.status === 'completed' ? 'bg-green-100 text-green-700' : t.status === 'in-progress' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-500'}`}>{t.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
