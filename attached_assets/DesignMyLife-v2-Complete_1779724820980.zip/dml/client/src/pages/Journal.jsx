import { useEffect, useState } from 'react';
import { Plus, Trash2, Sparkles, X, BookOpen, Loader2, ChevronDown } from 'lucide-react';
import { useAI } from '../context/AIContext';
import { journalAPI, aiAPI } from '../api/apiClient';

const MOODS = [
  { val:'great', emoji:'😄', label:'Great' },
  { val:'good',  emoji:'🙂', label:'Good'  },
  { val:'okay',  emoji:'😐', label:'Okay'  },
  { val:'bad',   emoji:'😔', label:'Bad'   },
  { val:'awful', emoji:'😢', label:'Awful' },
];
const MOOD_COLORS = { great:'bg-green-100 text-green-700', good:'bg-blue-100 text-blue-700', okay:'bg-gray-100 text-gray-600', bad:'bg-orange-100 text-orange-700', awful:'bg-red-100 text-red-700' };

export default function Journal() {
  const { aiEnabled, aiEffective } = useAI();
  const [entries,    setEntries]    = useState([]);
  const [showForm,   setShowForm]   = useState(false);
  const [expanded,   setExpanded]   = useState(null);
  const [analyzing,  setAnalyzing]  = useState(null);
  const [form, setForm] = useState({ title:'', content:'', mood:'okay', tags:'' });

  useEffect(() => { load(); }, []); // eslint-disable-line
  const load = async () => { try { const { data } = await journalAPI.getAll(); setEntries(data); } catch {} };

  const create = async e => {
    e.preventDefault();
    try {
      const { data } = await journalAPI.create({ ...form, tags: form.tags.split(',').map(t=>t.trim()).filter(Boolean) });
      setEntries(p => [data,...p]); setForm({ title:'',content:'',mood:'okay',tags:'' }); setShowForm(false);
    } catch {}
  };

  const del = async id => {
    if (!confirm('Delete this entry?')) return;
    try { await journalAPI.delete(id); setEntries(p=>p.filter(e=>e._id!==id)); } catch {}
  };

  const analyze = async (entry) => {
    setAnalyzing(entry._id);
    try {
      const { data: result } = await aiAPI.analyzeReflection({ text: entry.content, useAI: aiEffective });
      await journalAPI.saveAnalysis(entry._id, result);
      const updated = { ...entry, aiAnalysis: { ...result, analyzedAt: new Date() } };
      setEntries(p => p.map(e => e._id===entry._id ? updated : e));
      setExpanded(entry._id);
    } catch {} finally { setAnalyzing(null); }
  };

  const wordCount = text => text.trim().split(/\s+/).filter(Boolean).length;

  return (
    <div className="p-8 max-w-4xl">
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Journal</h1>
          <p className="text-gray-500 text-sm mt-1">{entries.length} entries · Your private space to reflect</p>
        </div>
        <button onClick={() => setShowForm(v=>!v)} className="btn-primary"><Plus size={16}/>New Entry</button>
      </div>

      {/* Create Form */}
      {showForm && (
        <div className="card mb-6 border-primary-100 bg-primary-50/30">
          <div className="flex items-center justify-between mb-4">
            <p className="font-bold text-gray-800">New Journal Entry</p>
            <button onClick={()=>setShowForm(false)}><X size={16} className="text-gray-400"/></button>
          </div>
          <form onSubmit={create} className="space-y-4">
            <div><label className="label">Title (optional)</label><input className="input" placeholder="Today's reflection..." value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))}/></div>
            <div><label className="label">How are you feeling?</label>
              <div className="flex gap-2 flex-wrap">
                {MOODS.map(m=>(
                  <button key={m.val} type="button" onClick={()=>setForm(p=>({...p,mood:m.val}))}
                    className={`px-3 py-2 rounded-xl border-2 text-sm font-semibold transition-all ${form.mood===m.val?'border-primary-500 bg-primary-50':'border-gray-200 bg-gray-50 hover:bg-gray-100'}`}>
                    {m.emoji} {m.label}
                  </button>
                ))}
              </div>
            </div>
            <div><label className="label">Write your thoughts *</label>
              <textarea className="input resize-none" rows={6} placeholder="What's on your mind today? How did things go? What did you learn?" value={form.content} onChange={e=>setForm(p=>({...p,content:e.target.value}))} required />
              <p className="text-[10px] text-gray-400 mt-1">{wordCount(form.content)} words</p>
            </div>
            <div><label className="label">Tags (comma-separated)</label><input className="input" placeholder="e.g. work, goals, health" value={form.tags} onChange={e=>setForm(p=>({...p,tags:e.target.value}))}/></div>
            <div className="flex gap-2"><button type="submit" className="btn-primary">Save Entry</button><button type="button" className="btn-secondary" onClick={()=>setShowForm(false)}>Cancel</button></div>
          </form>
        </div>
      )}

      {/* Entries */}
      {entries.length === 0 ? (
        <div className="card text-center py-16"><BookOpen size={40} className="text-gray-300 mx-auto mb-3"/><p className="text-gray-500 font-medium">No journal entries yet</p><p className="text-gray-400 text-xs mt-1">Start reflecting — even 5 minutes changes everything</p><button onClick={()=>setShowForm(true)} className="btn-primary mx-auto mt-4"><Plus size={14}/>Write First Entry</button></div>
      ) : (
        <div className="space-y-4">
          {entries.map(entry => (
            <div key={entry._id} className="card hover:shadow-sm transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-xl">{MOODS.find(m=>m.val===entry.mood)?.emoji || '😐'}</span>
                  <div>
                    <p className="font-bold text-gray-800">{entry.title || new Date(entry.createdAt).toLocaleDateString('en-IN',{weekday:'long',month:'long',day:'numeric'})}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`badge ${MOOD_COLORS[entry.mood]}`}>{MOODS.find(m=>m.val===entry.mood)?.label}</span>
                      <span className="text-[10px] text-gray-400">{entry.wordCount} words</span>
                      {entry.tags?.map(tag=><span key={tag} className="badge bg-gray-100 text-gray-500">#{tag}</span>)}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={()=>analyze(entry)} disabled={analyzing===entry._id}
                    className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl font-semibold transition-all ${aiEffective?'bg-violet-100 text-violet-700 hover:bg-violet-200':'bg-gray-100 text-gray-500 hover:bg-gray-200'} disabled:opacity-60`}>
                    {analyzing===entry._id?<Loader2 size={11} className="animate-spin"/>:<Sparkles size={11}/>}
                    {aiEffective?'AI Reflect':'Analyze'}
                  </button>
                  <button onClick={()=>setExpanded(p=>p===entry._id?null:entry._id)} className="text-gray-400 hover:text-gray-600"><ChevronDown size={16} className={`transition-transform ${expanded===entry._id?'rotate-180':''}`}/></button>
                  <button onClick={()=>del(entry._id)} className="text-gray-300 hover:text-red-400 transition-colors"><Trash2 size={14}/></button>
                </div>
              </div>

              <p className={`text-sm text-gray-600 leading-relaxed ${expanded===entry._id?'':'line-clamp-3'}`}>{entry.content}</p>

              {/* AI Analysis */}
              {expanded===entry._id && entry.aiAnalysis?.analyzedAt && (
                <div className="mt-4 rounded-xl border border-violet-100 bg-violet-50 p-4 space-y-3">
                  <p className="text-xs font-bold text-violet-700">⚡ {entry.aiAnalysis.mode==='ai'?'AI':'Basic'} Analysis</p>
                  {entry.aiAnalysis.sentiment&&<p className="text-xs text-gray-600">Sentiment: <strong className="text-violet-700">{entry.aiAnalysis.sentiment}</strong></p>}
                  {entry.aiAnalysis.themes?.length>0&&<div><p className="text-[10px] font-bold text-gray-600 uppercase tracking-wide mb-1">Themes</p><div className="flex gap-1 flex-wrap">{entry.aiAnalysis.themes.map((t,i)=><span key={i} className="badge bg-white text-violet-700 border border-violet-200">#{t}</span>)}</div></div>}
                  {entry.aiAnalysis.insights?.length>0&&<div><p className="text-[10px] font-bold text-gray-600 uppercase tracking-wide mb-1">Insights</p>{entry.aiAnalysis.insights.map((ins,i)=><p key={i} className="text-xs text-gray-600 flex gap-1.5 mb-1"><span className="text-violet-400">•</span>{ins}</p>)}</div>}
                  {entry.aiAnalysis.suggestions?.length>0&&<div><p className="text-[10px] font-bold text-gray-600 uppercase tracking-wide mb-1">Suggestions</p>{entry.aiAnalysis.suggestions.map((s,i)=><p key={i} className="text-xs text-gray-600 flex gap-1.5 mb-1"><span className="text-green-500">→</span>{s}</p>)}</div>}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
