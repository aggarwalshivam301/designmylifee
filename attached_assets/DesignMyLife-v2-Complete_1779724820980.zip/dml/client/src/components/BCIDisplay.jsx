import { Zap, TrendingUp, Info } from 'lucide-react';

const BARS = [
  { key: 'streakConsistency', label: 'Streak Consistency', weight: '40%', color: '#16a34a' },
  { key: 'completionRate',    label: 'Completion Rate',    weight: '30%', color: '#2563eb' },
  { key: 'timeConsistency',   label: 'Time Consistency',   weight: '20%', color: '#ca8a04' },
  { key: 'goalAlignment',     label: 'Goal Alignment',     weight: '10%', color: '#7c3aed' },
];

function GradeRing({ score }) {
  const color = score >= 80 ? '#16a34a' : score >= 65 ? '#2563eb' : score >= 50 ? '#ca8a04' : '#dc2626';
  const r = 46; const circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  return (
    <div className="relative flex items-center justify-center">
      <svg width="120" height="120">
        <circle cx="60" cy="60" r={r} fill="none" stroke="#e5e7eb" strokeWidth="8" />
        <circle cx="60" cy="60" r={r} fill="none" stroke={color} strokeWidth="8"
          strokeDasharray={circ} strokeDashoffset={offset}
          strokeLinecap="round" transform="rotate(-90 60 60)"
          style={{ transition: 'stroke-dashoffset 1s cubic-bezier(.4,0,.2,1)' }} />
      </svg>
      <div className="absolute text-center">
        <p className="text-2xl font-black" style={{ color }}>{score}</p>
        <p className="text-[10px] text-gray-400 font-semibold">/100</p>
      </div>
    </div>
  );
}

export default function BCIDisplay({ data, loading, compact = false }) {
  if (loading) return (
    <div className="card animate-pulse">
      <div className="h-4 bg-gray-200 rounded w-1/3 mb-4" />
      <div className="h-24 bg-gray-100 rounded mb-4" />
      <div className="space-y-3">
        {[1,2,3,4].map(i => <div key={i} className="h-3 bg-gray-100 rounded" />)}
      </div>
    </div>
  );

  if (!data) return null;

  const { score = 0, grade = 'N/A', breakdown = {}, interpretation = '', prediction = {}, mode, aiInsights } = data;
  const scoreColor = score >= 80 ? '#16a34a' : score >= 65 ? '#2563eb' : score >= 50 ? '#ca8a04' : '#dc2626';

  if (compact) return (
    <div className="flex items-center gap-4">
      <GradeRing score={score} />
      <div>
        <p className="text-2xl font-black" style={{ color: scoreColor }}>{score}<span className="text-sm font-semibold text-gray-400 ml-1">BCI</span></p>
        <p className="text-xs text-gray-500 mt-0.5">{interpretation}</p>
        <p className="text-xs mt-1 font-semibold" style={{ color: scoreColor }}>Grade: {grade}</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-5">
      {/* Header row */}
      <div className="flex items-center gap-4">
        <GradeRing score={score} />
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <p className="text-xs font-bold tracking-widest text-primary-600 uppercase">Behavioral Consistency Index</p>
            {mode === 'ai_enhanced' && (
              <span className="badge bg-violet-100 text-violet-700"><Zap size={10} />AI</span>
            )}
          </div>
          <p className="text-sm text-gray-600 leading-relaxed">{interpretation}</p>
          <div className="flex items-center gap-3 mt-2">
            <span className="badge text-white text-xs" style={{ background: scoreColor }}>Grade {grade}</span>
            <div className="flex items-center gap-1 text-xs text-gray-500">
              <TrendingUp size={12} className="text-primary-500" />
              <span>Success prob: <strong style={{ color: scoreColor }}>{prediction.successProbability}%</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Breakdown bars */}
      <div className="space-y-3">
        <p className="section-title">Score Breakdown</p>
        {BARS.map(bar => (
          <div key={bar.key}>
            <div className="flex justify-between text-xs mb-1">
              <span className="font-medium text-gray-700">{bar.label}</span>
              <div className="flex items-center gap-2">
                <span className="text-gray-400 text-[10px]">{bar.weight}</span>
                <span className="font-bold" style={{ color: bar.color }}>{breakdown[bar.key] ?? 0}</span>
              </div>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${breakdown[bar.key] ?? 0}%`, background: bar.color }} />
            </div>
          </div>
        ))}
      </div>

      {/* Formula */}
      <div className="bg-gray-50 rounded-xl p-3 border border-gray-100">
        <p className="text-[10px] font-mono text-gray-400">BCI = (S×0.4) + (C×0.3) + (T×0.2) + (G×0.1)</p>
      </div>

      {/* Recommendation */}
      {prediction.recommendation && (
        <div className="flex gap-2.5 p-3 rounded-xl bg-primary-50 border border-primary-100">
          <Info size={14} className="text-primary-600 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-primary-700">{prediction.recommendation}</p>
        </div>
      )}

      {/* AI Insights */}
      {mode === 'ai_enhanced' && aiInsights && (
        <div className="rounded-xl border border-violet-100 bg-gradient-to-br from-violet-50 to-purple-50 p-4 space-y-3">
          <p className="section-title text-violet-600">⚡ AI-Enhanced Insights</p>

          {aiInsights.patterns?.length > 0 && (
            <div>
              <p className="text-xs font-bold text-gray-700 mb-1.5">📍 Patterns</p>
              {aiInsights.patterns.map((p, i) => (
                <p key={i} className="text-xs text-gray-600 flex gap-1.5 mb-1"><span className="text-violet-400">•</span>{p}</p>
              ))}
            </div>
          )}

          {aiInsights.actionableTips?.length > 0 && (
            <div>
              <p className="text-xs font-bold text-gray-700 mb-1.5">💡 Actions</p>
              {aiInsights.actionableTips.map((t, i) => (
                <div key={i} className="flex gap-2 mb-1.5">
                  <span className="w-4 h-4 rounded-full bg-violet-200 text-violet-700 text-[10px] font-bold flex items-center justify-center flex-shrink-0">{i+1}</span>
                  <p className="text-xs text-gray-600">{t}</p>
                </div>
              ))}
            </div>
          )}

          {aiInsights.weeklyFocus && (
            <div className="bg-white rounded-lg p-2.5 border border-violet-100">
              <p className="text-[10px] text-violet-500 font-bold uppercase mb-0.5">This Week's Focus</p>
              <p className="text-xs text-gray-700">{aiInsights.weeklyFocus}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
