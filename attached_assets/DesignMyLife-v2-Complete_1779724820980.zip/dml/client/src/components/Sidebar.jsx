import { NavLink } from 'react-router-dom';
import { LayoutDashboard, CheckSquare, Target, ListChecks, BarChart2, BookOpen, Timer, Settings, Sparkles, Zap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAI }   from '../context/AIContext';

const NAV = [
  { to: '/',          icon: LayoutDashboard, label: 'Dashboard'  },
  { to: '/habits',    icon: CheckSquare,     label: 'Habits'     },
  { to: '/goals',     icon: Target,          label: 'Goals'      },
  { to: '/tasks',     icon: ListChecks,      label: 'Tasks'      },
  { to: '/analytics', icon: BarChart2,       label: 'Analytics'  },
  { to: '/journal',   icon: BookOpen,        label: 'Journal'    },
  { to: '/focus',     icon: Timer,           label: 'Focus'      },
];

export default function Sidebar() {
  const { user, logout }                               = useAuth();
  const { aiEnabled, aiConfigured, aiEffective, toggleAI } = useAI();

  return (
    <aside className="w-[220px] min-h-screen flex flex-col" style={{ background: '#1e1b4b' }}>

      {/* Logo */}
      <div className="flex items-center gap-3 px-6 py-7 border-b border-white/10">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-700 to-blue-600 flex items-center justify-center text-white text-lg font-bold flex-shrink-0">✦</div>
        <div>
          <p className="text-white font-black text-sm leading-tight">DesignMyLife</p>
          <p className="text-indigo-300 text-[9px] tracking-widest uppercase">Productivity OS</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-4 px-3 space-y-0.5">
        {NAV.map(({ to, icon: Icon, label }) => (
          <NavLink key={to} to={to} end={to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-primary-700/40 text-primary-200 border-l-2 border-primary-400 pl-[10px]'
                  : 'text-indigo-300 hover:bg-white/5 hover:text-indigo-100'
              }`
            }>
            <Icon size={16} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* AI Global Toggle */}
      <div className="mx-3 mb-3 rounded-xl border border-white/10 bg-white/5 p-4">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <Sparkles size={13} className="text-violet-300" />
            <span className="text-xs font-bold text-white">AI Features</span>
          </div>
          <button onClick={toggleAI}
            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors duration-300 focus:outline-none ${aiEnabled ? 'bg-primary-600' : 'bg-gray-600'}`}>
            <span className={`inline-block h-3.5 w-3.5 rounded-full bg-white shadow transition-transform duration-300 ${aiEnabled ? 'translate-x-4' : 'translate-x-1'}`} />
          </button>
        </div>
        <p className="text-[10px] leading-tight mt-1">
          {aiEffective
            ? <span className="text-green-400 flex items-center gap-1"><Zap size={9} />Active — AI enhanced</span>
            : aiEnabled && !aiConfigured
              ? <span className="text-amber-400">On · No API key set</span>
              : <span className="text-indigo-400">Off · BCI math active</span>
          }
        </p>
      </div>

      {/* Settings + User */}
      <div className="border-t border-white/10 px-3 py-3 space-y-0.5">
        <NavLink to="/settings"
          className={({ isActive }) =>
            `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
              isActive ? 'bg-primary-700/40 text-primary-200' : 'text-indigo-300 hover:bg-white/5 hover:text-indigo-100'
            }`
          }>
          <Settings size={16} /> Settings
        </NavLink>

        <div className="flex items-center gap-3 px-3 py-2.5">
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary-600 to-blue-600 flex items-center justify-center text-white font-bold text-xs flex-shrink-0">
            {user?.name?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-indigo-100 text-xs font-semibold truncate">{user?.name}</p>
            <button onClick={logout} className="text-indigo-400 text-[10px] hover:text-red-400 transition-colors">Sign out</button>
          </div>
        </div>
      </div>
    </aside>
  );
}
