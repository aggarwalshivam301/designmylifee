import axios from 'axios';

const BASE = import.meta.env.VITE_API_URL || '/api';
const ax   = axios.create({ baseURL: BASE });

ax.interceptors.request.use(cfg => {
  const token = localStorage.getItem('dml_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

ax.interceptors.response.use(
  r => r,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('dml_token');
      localStorage.removeItem('dml_user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// ── Auth ────────────────────────────────────────────────────────────────────
export const authAPI = {
  login:           (email, password) => ax.post('/auth/login', { email, password }),
  register:        (name, email, password) => ax.post('/auth/register', { name, email, password }),
  getProfile:      ()      => ax.get('/auth/profile'),
  updateProfile:   (data)  => ax.put('/auth/profile', data),
  changePassword:  (data)  => ax.put('/auth/change-password', data),
  toggleAI:        (val)   => ax.put('/auth/toggle-ai', { aiEnabled: val }),
};

// ── Habits ──────────────────────────────────────────────────────────────────
export const habitsAPI = {
  getAll:   ()     => ax.get('/habits'),
  create:   (data) => ax.post('/habits', data),
  update:   (id, data) => ax.put(`/habits/${id}`, data),
  delete:   (id)   => ax.delete(`/habits/${id}`),
  checkIn:  (id)   => ax.post(`/habits/${id}/checkin`),
  getStats: (id)   => ax.get(`/habits/${id}/stats`),
};

// ── Goals ───────────────────────────────────────────────────────────────────
export const goalsAPI = {
  getAll:       ()          => ax.get('/goals'),
  create:       (data)      => ax.post('/goals', data),
  update:       (id, data)  => ax.put(`/goals/${id}`, data),
  delete:       (id)        => ax.delete(`/goals/${id}`),
  linkHabit:    (id, habitId) => ax.post(`/goals/${id}/link-habit`, { habitId }),
  unlinkHabit:  (id, habitId) => ax.delete(`/goals/${id}/link-habit/${habitId}`),
  setMilestones:(id, milestones) => ax.put(`/goals/${id}/milestones`, { milestones }),
};

// ── Tasks ───────────────────────────────────────────────────────────────────
export const tasksAPI = {
  getAll:   (params) => ax.get('/tasks', { params }),
  getToday: ()       => ax.get('/tasks/today'),
  create:   (data)   => ax.post('/tasks', data),
  update:   (id, data) => ax.put(`/tasks/${id}`, data),
  delete:   (id)     => ax.delete(`/tasks/${id}`),
};

// ── Journal ──────────────────────────────────────────────────────────────────
export const journalAPI = {
  getAll:       ()          => ax.get('/journal'),
  getOne:       (id)        => ax.get(`/journal/${id}`),
  create:       (data)      => ax.post('/journal', data),
  update:       (id, data)  => ax.put(`/journal/${id}`, data),
  delete:       (id)        => ax.delete(`/journal/${id}`),
  saveAnalysis: (id, analysis) => ax.put(`/journal/${id}/ai-analysis`, { analysis }),
};

// ── AI ───────────────────────────────────────────────────────────────────────
export const aiAPI = {
  getStatus:         ()          => ax.get('/ai/status'),
  analyzeBehavior:   (data)      => ax.post('/ai/analyze-behavior', data),
  quickBCI:          (data)      => ax.post('/ai/quick-bci', data),
  decomposeGoal:     (data)      => ax.post('/ai/decompose-goal', data),
  analyzeReflection: (data)      => ax.post('/ai/analyze-reflection', data),
  optimizeTasks:     (data)      => ax.post('/ai/optimize-tasks', data),
};

export default ax;
